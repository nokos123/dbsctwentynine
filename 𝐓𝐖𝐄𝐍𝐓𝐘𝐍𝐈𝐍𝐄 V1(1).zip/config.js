module.exports = {
  TOKEN_BOTLU: "", 
  OWNER_ID: [""],
};