# NOT SHARE PUBLIK
# NOT SHARE FRIEND
# PAKE BUAT PRIBADI
===========================================
# HARGAI GW
===========================================